<?php

include_once('header.php');

unset($argv[0]);// to remove the first index which will be path of cron
$thread_id = $argv[1];

if(isset($_GET['id'])){
	$thread_id = $_GET['id'];
}

echo "\n\n";
echo date('H:i:s');
echo "\n\n";

echo '<pre>';

	$start_time = date('Y-m-d H:i:s',time());
	$end_time = date('Y-m-d H:i:s',time()-($follow_minutes_to_process*60));
	
	$db->query($objMass_Follow->get_content($thread_id,$start_time,$follow_minutes_to_process));
	$all_content = $db->fetch_all_assoc();
	
	$db->execute($objMass_Follow->delete_content($thread_id,$start_time));
	$db->execute("OPTIMIZE TABLE follow_thread_".$thread_id);
	
	echo "\n\n";
	echo "Total Records = ".count($all_content);
	echo "\n\n";
	$db_values = array();
	foreach($all_content as $c){
		$out = preg_replace('!s:(\d+):"(.*?)";!se', "'s:'.strlen('$2').':\"$2\";'", $c['content']);
		$sch = unserialize($out);
		
		if(DEBUG_MODE){
			echo "<pre>";
			echo $c['content'];
			echo "\n\n";
			print_r($sch);
		}
		
		if(!isset($sch['screen_name'])){
			$result = array();
			$main_keyword = "";
			switch($sch['type']){
				case 'list':
					$list_param = explode(':', $sch['params']);			
					$list = explode(",",$list_param[1]);
					shuffle($list);
					$list = array_chunk($list,$sch['count']);
					$result = array();
					foreach($list[0] as $ls){
						$f_screen_name = trim(str_replace("\n","",$ls));
						$result[] = $f_screen_name;
					}
					break;
				
				case 'keyword':
					$keyword = '';
					if(strpos($sch['keywords'],",") !== FALSE){
						$list = explode(',', $sch['keywords']);
						if(count($list) > 1) {
							$keyword = $objCommon->formatKeyword($list[array_rand($list,1)]);
						}
					}
					else{
						$keyword = $sch['keywords'];
					}
					echo "\n\n Keyword = ".$keyword."\n\n";
					if(!empty($keyword)){
						$main_keyword = $keyword;
						$keyword  = addslashes($keyword);
						$acc = array('username' => $sch['username'],'password' => $sch['password'],'email' => $sch['email'],'proxy' => $sch['proxy']);
						$result = $objBasicFunction->search_users($acc,$sch,$keyword);
					}
					break;
				default:
				
				break;
			}			
			if(count($result)>0){
				$insert_sql = "INSERT INTO follow_thread_".$thread_id." (content,publish_date,schedule_id) VALUES ";
					
				foreach($result as $r_u){
						$arr = array();			
						$arr['screen_name'] = $r_u;
						$arr['username'] = $sch['username'];
						$arr['email'] = $sch['email'];
						$arr['password'] = $sch['password'];
						$arr['proxy'] = $sch['proxy'];
						if($sch['type'] == 'list'){
							$arr['param'] = $r_u;
						}
						else{
							$arr['param'] = $main_keyword;
						}
						$time_random = rand(time(),(intval(strtotime($c['publish_date'])+($sch['period']*60))));
						$date_time = date('Y-m-d H:i:s',$time_random);
						$insert_sql .= "('".serialize($arr)."','".$date_time."',".$c['schedule_id']."),";
				}
				$insert_sql = substr($insert_sql, 0, -1)."; ";
				$db->execute($insert_sql);
			}
		}
		else{	
				$auth_token = $objBasicFunction->authenticate($sch);
				if($auth_token){					
					$follow_result = $objBasicFunction->follow_single($sch,$sch['screen_name'],$auth_token);
					if($follow_result){
						$table_fields = $objCommon->get_follow_table_name($sch['username']);
						echo "\n Table = ".$table_fields['table_name'];
						echo "\n Username = ".$sch['username'];
						echo "\n User to follow = ".$sch['screen_name'];
						echo "\n";
						$db_values[$table_fields['table_name']][] = "('".strtolower($sch['username'])."','".$sch['screen_name']."',1,NOW())";								
					}
				}

		}

	}
	
	if(count($db_values)>0){
		foreach($db_values as $key=>$th){
			$insert_sql = "";
			$db->execute($objMass_Follow->create_user_follow_table($key));
			$insert_sql = "INSERT INTO follow_table_".$key." (username,follow_name,status,date) VALUES ".implode(",",$th);
			//$insert_sql = substr($th, 0, -1)."; ";
			$result = $db->execute($insert_sql);
		}
	}
	
	

//$currentProcess = SITE_PATH."follow_poster_db_new.php ".$thread_id;
$currentProcess = "";

echo "\n\n\n";
echo " End Time ";
echo "\n\n\n";
echo date('H:i:s');
echo "\n\n\n";

include_once('footer.php');


