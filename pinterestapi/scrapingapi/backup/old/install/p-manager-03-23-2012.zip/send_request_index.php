<?php

	include_once('header.php');
	$thread_count = shell_exec("/bin/ps aux | /bin/grep '".SITE_PATH."send_request.php' -c");
	//$threadCount = shell_exec("/bin/ps aux | /bin/grep '".SITE_PATH."mass_schedular.php' -c");
	//echo "\n Thread = ".$threadCount ."\n";
	if($thread_count<=2){
		$available_thread = $signup_requests_thread;
	}
	else{
		$available_thread = $signup_requests_thread-($thread_count-1);
	}

	//echo "\navailableThread = ".$availableThread;
	//echo "\n";
	
	$limit = $available_thread*$signup_requests_tasks_per_thread;
	
	$db->query($objAccounts->listAccountsToBeRequested($limit));
	$users = $db->fetch_all_assoc();
	$user_names = array();
	if(count($users)>0){
		foreach($users as $us){
			$user_names[] = $us['username'];
		}
		//$db->execute($objAccounts->updateInProcess($user_names,1));
		$current_thread_count = ceil(count($users)/$available_thread);
		$thread_chunks = array_chunk($user_names,$current_thread_count);
		echo '<pre>';
		print_r($thread_chunks);
		
		foreach($thread_chunks as $chunks){
			$threads = implode(",",$chunks);
			
			echo "/usr/bin/nohup  /usr/bin/php ".SITE_PATH."send_request.php ".$threads."& ";
			echo "\n\n";
			shell_exec("/usr/bin/nohup  /usr/bin/php ".SITE_PATH."send_request.php ".$threads."  > /dev/null & echo $!");
			//$threadCount = shell_exec("/bin/ps aux | /bin/grep '".SITE_PATH."mass_schedular_db.php' -c");
			
			
		}
	}
$db->close();
