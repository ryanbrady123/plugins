<?php

	include_once('header.php');
	$threadCount = shell_exec("/bin/ps aux | /bin/grep '".SITE_PATH."unfollow_mass_scheduler.php' -c");
	//$threadCount = shell_exec("/bin/ps aux | /bin/grep '".SITE_PATH."mass_schedular.php' -c");
	if($threadCount<=2){
		$availableThread = $mass_un_follow_threads;
	}
	else{
		$availableThread = $mass_un_follow_threads-($threadCount-1);
	}

	
	$limit = $availableThread*$mass_un_follow_tasks;
	$db->query($objMass_Un_Follow->getRecordsId($limit));
	$schedules = $db->fetch_all_assoc();
	$schedules_ids = array();
	if(count($schedules)>0){
		foreach($schedules as $sc){
			$schedules_ids[] = $sc['id'];
		}
		
		$all_ids = implode(",",$schedules_ids);
		
		$objMass_Un_Follow->setId($all_ids);
		$objMass_Un_Follow->setStatus(time());
		$db->execute($objMass_Un_Follow->updateStatusByIds());
		$current_thread_count = ceil(count($schedules)/$availableThread);
		$thread_chunks = array_chunk($schedules_ids,$current_thread_count);		
		foreach($thread_chunks as $chunks){
			$threads = implode(",",$chunks);
			
			echo "/usr/bin/nohup  /usr/bin/php ".SITE_PATH."unfollow_mass_scheduler.php ".$threads."& ";
			echo "\n\n";
			shell_exec("/usr/bin/nohup  /usr/bin/php ".SITE_PATH."unfollow_mass_scheduler.php ".$threads."  > /dev/null & echo $!");
			//$threadCount = shell_exec("/bin/ps aux | /bin/grep '".SITE_PATH."mass_schedular_db.php' -c");
			
			
		}
	}
$db->close();
