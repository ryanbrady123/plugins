<?php
class GoogleImageSearchBuilderNew extends FeedBuilderNew
{
	public function ajaxResponse($howMany = 10)
	{
		$response[] = '<li id="not_found">'.NO_RESULTS_MSG.'</li>';
		//$Feeds = common::getFeedsAfterExcludingUrls($this->getFeeds(),true,'images.google.com');
		if ($items = $this->getFeeds())
		{
			$response = $items;
			/*foreach ($this->Feeds as $counter => $item)
			{
				$response[$counter]['title'] .= $item->contentNoFormatting();
				$response[$counter]['img'] .= $item->tbUrl();
				$response[$counter]['img_url'] .= $item->url();
				$response[$counter]['link'] .= $item->originalContextUrl();

				if ($counter == $howMany-1)
				{
					break;
				}
			}*/
		}
		return $response; 
	}
}
?>