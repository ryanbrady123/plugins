<?php

class Options extends Common{
    
    private $id;
    private $name;
    private $value;
    private $description;
	private $tableName;

   function Options() {
        $this->id = 0;
        $this->name = "";
        $this->value = "";
        $this->description = "";
        $this->tableName = "options";
    }

     public function getId() {
        return $this->id;
    }

    public function setId($val) {
        $this->id = $val;
    }

    public function getName() {
        return $this->name;
    }

    public function setName($val) {
        $this->name = $val;
    }

    public function getValue() {
        return $this->value;
    }

    public function setValue($val) {
        $this->value = $val;
    }

    public function getDescription() {
        return $this->description;
    }

    public function setDescription($val) {
        $this->description = $val;
    }

	public function selectAll(){
		$sql = "SELECT * FROM " .$this->tableName;
		return $sql;
	}

  
}

?>