<?php

include_once('header.php');

define('FOLLOW_THREADS',$mass_follow_threads);


unset($argv[0]);// to remove the first index which will be path of cron
$implode_str = $argv[1];

if(isset($_GET['id'])){
	$implode_str = $_GET['id'];
}
echo "\n\n";
echo date('H:i:s');
echo "\n\n";

echo '<pre>';
$db->query($objMass_Follow->getRecordsById($implode_str));
$schedules = $db->fetch_all_assoc();

$per_account_count_types = array('googleblogsearch','googlenews','yahoonews','basic_account','quote');
$total_count_types = array('basic','feed','fs-title','fs-title-account');



$thread_number = 1;
$array_thread = array();


$complete_array = array();
$count_files = 0;

foreach($schedules as $sch){
	$accounts_all = array();
	echo $objAccounts->getAccountByNotesForMassfollow($sch['notes']);
	$db->query($objAccounts->getAccountByNotesForMassfollow($sch['notes']));
	$accounts = $db->fetch_all_assoc();
	
	echo " <br> Total Acvcounts = ".count($accounts);
	echo "<br>";
	
	if(intval($thread_number) > FOLLOW_THREADS){
		$thread_number = 1;
	}
	if(count($accounts)>0){
		foreach($accounts as $acc){
			if(intval($thread_number) > FOLLOW_THREADS){
				$thread_number = 1;
			}
			$keywords = addslashes($acc['follow_keywords']);
			$file_data = array(	
								'username'			=>	strtolower($acc['username']),
								'email'				=>	strtolower($acc['email']),
								'password'			=>	$acc['password'],
								'proxy'				=>	$acc['proxy'],
								'type'				=>	$sch['type'],
								'params'			=>	$sch['params'],
								'count'				=>	$sch['count'],
								'keywords'			=>	$keywords,
								'period'			=>	$sch['period']
								);
			$time_random = rand(time(),(time()+(intval($sch['period'])*60)));
			$date_time = date('Y-m-d H:i:s',$time_random);	
			$array_thread[$thread_number][] = "('".serialize($file_data)."' , '".$date_time."',".$sch['id'].")";
			$thread_number++;
		}
	}
	
	$next_run_temp = time()+(intval($sch['period'])*60);
	$next_run = date('Y-m-d H:i:s',$next_run_temp);
	
	$db->execute("UPDATE follow_scheduler SET next_run = '".$next_run."' , status = 0 WHERE id = ".$sch['id']);
}

/// Execute Queries
foreach($array_thread as $key=>$th){
	$insert_sql = "";
	$db->execute($objMass_Follow->create_table($key));
	$insert_sql = "INSERT INTO follow_thread_".$key." (content,publish_date,schedule_id) VALUES ".implode(",",$th);
	
	//$insert_sql = substr($th, 0, -1)."; ";
	$result = $db->execute($insert_sql);	
}

$currentProcess = SITE_PATH."follow_mass_scheduler.php ".$implode_str;

$end_time = microtime();

echo "\n\n\n";
echo " End Time ";
echo "\n\n\n";
echo date('H:i:s');
echo "\n\n\n";

include_once('footer.php');