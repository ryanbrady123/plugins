<?php

include_once('header.php');

define('POSTER_THREADS',$poster_threads);


unset($argv[0]);// to remove the first index which will be path of cron
$implode_str = $argv[1];

if(isset($_GET['id'])){
	$implode_str = $_GET['id'];
}
echo "\n\n";
echo date('H:i:s');
echo "\n\n";

echo '<pre>';


if(!file_exists(SITE_PATH.$scheduled_templates_folder_name)){
	mkdir(SITE_PATH.$scheduled_templates_folder_name,0777);
}
$db->query($objMass_Schedular->getRecordsById($implode_str));
$schedules = $db->fetch_all_assoc();

$per_account_count_types = array('googleblogsearch','googlenews','yahoonews','basic_account','quote','googleblogsearchcount','googlenewscount','yahoonewscount','amazoncount');
$total_count_types = array('basic','feed','fs-title','fs-title-account','amazon');


// templates names
$description_template = 'description_template';
$url_template = 'url_template';
$picture_url_template = 'picture_url_template';


$thread_number = 1;
$array_thread = array();


$complete_array = array();
$count_files = 0;

foreach($schedules as $sch){
	$accounts_all = array();
	//echo $objAccounts->getAccountByNotesForMass($sch['notes']);
	$db->query($objAccounts->getAccountByNotesForMass($sch['notes']));
	$accounts = $db->fetch_all_assoc();
	$accounts_all['schedule'] = $sch;
	//$accounts_all['accounts'] = $accounts;
	
	$per_account = 0;//if 0 nothing, if 1 "per account count", if 2 total "count"\
	
	if($sch['count_type'] == 'account'){
		$per_account = 1;
	}
	elseif($sch['count_type'] == 'total'){
		$per_account = 2;
	}
		
	if($sch['type'] != 'quote' && (intval($sch['cached']) == 0)){
		//$temp = array($sch['template']);
		//$final_output = array();	
		//$final_output = $objCommon->make_template($final_output, $temp);
		//file_put_contents(SITE_PATH.$scheduled_templates_folder_name."/".$sch['id'].".parr",serialize($final_output));
		
		// for description_template				
		$temp = array(trim($sch[$description_template]));
		$final_output = array();
		
		$final_output = $objCommon->make_template_unqiue($temp);
		file_put_contents(SITE_PATH.$scheduled_templates_folder_name."/".$sch['id']."_".$description_template.".parr",serialize($final_output));
		
		// for url_template
		$temp = array($sch[$url_template]);
		$final_output = array();
		$final_output = $objCommon->make_template_unqiue($temp);
		file_put_contents(SITE_PATH.$scheduled_templates_folder_name."/".$sch['id']."_".$url_template.".parr",serialize($final_output));
		
		// for picture_url_template
		$temp = array($sch[$picture_url_template]);
		$final_output = array();	
		$final_output = $objCommon->make_template_unqiue($temp);
		file_put_contents(SITE_PATH.$scheduled_templates_folder_name."/".$sch['id']."_".$picture_url_template.".parr",serialize($final_output));
	}
	
	$templates = array();
	if($sch['type'] != 'quote'){
		//$templates = unserialize(file_get_contents(SITE_PATH.$scheduled_templates_folder_name."/".$sch['id'].".parr"));
		$templates[$description_template] = unserialize(file_get_contents(SITE_PATH.$scheduled_templates_folder_name."/".$sch['id']."_".$description_template.".parr"));	
		$templates[$url_template] = unserialize(file_get_contents(SITE_PATH.$scheduled_templates_folder_name."/".$sch['id']."_".$url_template.".parr"));	
		$templates[$picture_url_template] = unserialize(file_get_contents(SITE_PATH.$scheduled_templates_folder_name."/".$sch['id']."_".$picture_url_template.".parr"));
	}
	
	$accounts_all['boards'] = explode("|??|",$sch['boards']);
	$accounts_all['templates'] = $templates;
	$accounts_all['account_count'] = count($accounts);
		
		$quotes = array();
	
	if($sch['type'] == 'quote'){
		//shuffle($quotes);
		$db->query("SELECT content FROM quotes");
		$quotes = $db->fetch_all_assoc();
		$accounts_all['quotes'] = $quotes;
	}
		
	$this_count = 0;
	if($per_account == 1){
		$this_count = $sch['count'];
		//$this_count = $sch['count']*count($accounts);
	}
	elseif($per_account == 2){
		$this_count = $sch['count'];
	}
	
	/*if(strtolower($sch['type']) == 'googleblogsearchcount' || strtolower($sch['type']) == 'googlenewscount' || strtolower($sch['type']) == 'yahoonewscount' || strtolower($sch['type']) == 'amazoncount'){
		$this_count = 1;
	}*/
	
		echo "\n Per Account = ".$per_account."\n";
		echo "\n This Count = ".$this_count."\n";
		
		$accounts_all['sch_count'] = $this_count;
		
		echo "<br> No of Acounts = ".count($accounts)."<br>";
		$iterations = ceil($this_count / count($accounts));
		if($per_account == 1){
			$accounts_all['all_accounts'] = array_fill(0,$iterations,$accounts);
		}
		elseif($per_account == 2){
			if($this_count<count($accounts)){
				$acounts_chunks = array_chunk($accounts,$this_count);
				$accounts_all['all_accounts'][] = $acounts_chunks[0];
			}
			else{
				$accounts_all['all_accounts'] = array_fill(0,$iterations,$accounts);
			}
		}
		
		echo "\n No of Entries = ".count($accounts_all['all_accounts'])."\n";
		$complete_array[] = $accounts_all;
		unset($accounts_all);

	$next_run_temp = time()+(intval($sch['period'])*60);
	$next_run = date('Y-m-d H:i:s',$next_run_temp);
	$chached_sql = "";
	if(intval($sch['cached']) == 0 && $sch['type'] != 'quote'){
		$chached_sql = " , cached = 1";
	}	
	echo "\n\n\n\n";
	echo "UPDATE mass_scheduler SET next_run = '".$next_run."' ".$chached_sql." , status = 0 WHERE id = ".$sch['id'];
	$db->execute("UPDATE mass_scheduler SET next_run = '".$next_run."' ".$chached_sql." , status = 0 WHERE id = ".$sch['id']);
}


foreach($complete_array as $acc_key=>$sch){
	$current_template = "";
	echo "\n\n\n";
	echo "Total Accounts = ".(count($sch['all_accounts'])*count($sch['all_accounts'][0]));
	echo "\n\n\n";
	array_walk($sch['all_accounts'],'array_walk_files',$sch);
}
unset($complete_array);

/// Execute Queries
foreach($array_thread as $key=>$th){
	$insert_sql = "";
	$db->execute($objMass_Schedular->create_table($key));
	$insert_sql = "INSERT INTO thread_".$key." (`content`,`publish_date`,`schedule_id`) VALUES ".implode(",",$th);
	//$insert_sql = substr($th, 0, -1)."; ";
	$result = $db->execute($insert_sql);	
}

function array_walk_files($values, $skey, $sch){
	//echo "\n array_walk_files = ".$skey;
	//echo "\n";
	array_walk($values,'make_files',$sch);
}

function make_files($acc, $skey,$sch){
	
	global $thread_number,$count_files,$array_thread,$db,$objMass_Schedular;
	global $description_template, $url_template ,$picture_url_template;
	
	if(intval($thread_number) > POSTER_THREADS){
		$thread_number = 1;
	}
	
	/*echo "<pre>";
	print_r($acc);
	print_r($sch);
	exit;*/
	$keyword = "";
	$params = array();
	if($sch['schedule']['type'] != 'quote'){
		//shuffle($templates);
		//$current_template = $sch['templates'][array_rand($sch['templates'],1)];
		$current_template[$description_template] = addslashes($sch['templates'][$description_template][array_rand($sch['templates'][$description_template],1)]);
		$current_template[$url_template] = addslashes($sch['templates'][$url_template][array_rand($sch['templates'][$url_template],1)]);
		$current_template[$picture_url_template] = addslashes($sch['templates'][$picture_url_template][array_rand($sch['templates'][$picture_url_template],1)]);
	}
	
	$keywords_list = array();
	if($sch['schedule']['keyword_source'] == 'scheduler'){
		$keywords_list = explode(",",$sch['schedule']['mass_keywords']);
	}
	else{
		$keywords_list = explode(",",$acc['keywords']);
	}				
	$keyword = $keywords_list[array_rand($keywords_list,1)];
	$keyword = str_replace(" ","+",$keyword);
	$keyword = addslashes($keyword);
	$is_count_source = 0;
	if($sch['schedule']['source_cache']){
		$is_count_source = 1;
	}
	$url = "";
	switch($sch['schedule']['type']){
		case 'googleblogsearchcount':
			$url = GOOGLE_BLOG_SEACRH_URL.$keyword;
			$url = str_replace('$lang$',$sch['schedule']['lang'],$url);
			break;
		
		case 'googlenewscount':
			$url = GOOGLE_NEWS_URL.$keyword;
			$url = str_replace('$lang$',$sch['schedule']['lang'],$url);
			break;
		
		case 'yahoonewscount':
			$url = YAHOO_NEWS_URL.$keyword;					
			$language = $sch['schedule']['lang'];
			if($sch['schedule']['type'] == 'yahoonews'){
				$yahooLangArray = array('zh-CN'=>'szh','zh-TW'=>'tzh');
				if(isset($yahooLangArray[$language])){
					$language = $yahooLangArray[$language];
				}
			}
			$url = str_replace('$lang$',trim($language),$url);
			break;
		
		case 'googleblogsearch':
			$url = GOOGLE_BLOG_SEACRH_URL.$keyword;
			$url = str_replace('$lang$',$sch['schedule']['lang'],$url);
			break;
		
		case 'googlenews':
			$url = GOOGLE_NEWS_URL.$keyword;
			$url = str_replace('$lang$',$sch['schedule']['lang'],$url);
			break;
		
		case 'yahoonews':
			$url = YAHOO_NEWS_URL.$keyword;					
			$language = $sch['schedule']['lang'];
			if($sch['schedule']['type'] == 'yahoonews'){
				$yahooLangArray = array('zh-CN'=>'szh','zh-TW'=>'tzh');
				if(isset($yahooLangArray[$language])){
					$language = $yahooLangArray[$language];
				}
			}						
			$url = str_replace('$lang$',trim($language),$url);
			break;
		
		case 'quote':
			$current_template  = addslashes($sch['quotes'][array_rand($sch['quotes'],1)]['content']);
			break;
			
		case 'fs-title':
			$fs_url_list = array();
			if($sch['schedule']['url_source'] == 'scheduler'){
				$fs_url_list = explode("||",$sch['schedule']['urls']);
			}
			else{
				$fs_url_list = explode("||",$acc['site']);
			}
			$url = $fs_url_list[array_rand($fs_url_list,1)];
			$params['fast_site_url'] = $url;
			$url = $url."recent?term=".str_replace(' ','+',$keyword);
			if(!empty($sch['schedule']['fs_params'])){
				$params_list = explode(",",$sch['schedule']['fs_params']);
				$count = $params_list[0];
				$source = $params_list[1];
				$url = $url."&source=".$source."&count=".$count;
				$params['fs_params'] = array('count'=>$count,'source'=>$source);
			}				
			break;		
		case 'fs-title-account':
			$fs_url_list = array();
			if($sch['schedule']['url_source'] == 'scheduler'){
				$fs_url_list = explode("||",$sch['schedule']['urls']);
			}
			else{
				$fs_url_list = explode("||",$acc['site']);
			}
			$url = $fs_url_list[array_rand($fs_url_list,1)];
			$params['fast_site_url'] = $url ;
			$url = $acc['site']."recent?term=".str_replace(' ','+',$keyword);
			if(!empty($sch['schedule']['fs_params'])){
				$params_list = explode(",",$sch['schedule']['fs_params']);
				$count = $params_list[0];
				$source = $params_list[1];
				$url = $url."&source=".$source."&count=".$count;
				$params['fs_params'] = array('count'=>$count,'source'=>$source);
			}	
			break;
		
		case 'feed':
			$feed_url_list = array();
			if($sch['schedule']['url_source'] == 'scheduler'){
				$feed_url_list = explode("||",$sch['schedule']['urls']);
			}
			else{
				$feed_url_list = explode("||",$acc['feed_url_list']);
			}
			$url = $feed_url_list[array_rand($feed_url_list,1)];
			$url = str_replace('$keyword$',$keyword,$url);
			break;
		
		case 'amazon':
			$feed_url_list = array();
			if($sch['schedule']['url_source'] == 'scheduler'){
				$feed_url_list = explode("||",$sch['schedule']['urls']);
			}
			else{
				$feed_url_list = explode("||",$acc['feed_url_list']);
			}
			$url = $feed_url_list[array_rand($feed_url_list,1)];
			$url = str_replace('$keyword$',$keyword,$url);
						
			if(!empty($sch['schedule']['fs_params'])){
				$url = $url.$sch['schedule']['fs_params'];
			}
			break;
		case 'amazoncount':
			$feed_url_list = array();
			if($sch['schedule']['url_source'] == 'scheduler'){
				$feed_url_list = explode("||",$sch['schedule']['urls']);
			}
			else{
				$feed_url_list = explode("||",$acc['feed_url_list']);
			}
			//$feed_url_list = explode(",",$sch['schedule']['urls']);
			$url = $feed_url_list[array_rand($feed_url_list,1)];
			$url = str_replace('$keyword$',$keyword,$url);
			if(!empty($sch['schedule']['fs_params'])){
				$url = $url.$sch['schedule']['fs_params'];
			}
			break;
		default:
			break;
	}
	
	
	if($url != ""){
		$params['simple_url'] = $url;
	}
	//if($is_count_source){
		$params['all_templates'] = $sch['schedule']['id'];
		
	//}
	if($sch['schedule']['count_type'] == 'account'){
		$params['user_count'] = $sch['schedule']['count'];
	}
	$file_data = array(	
							'username'			=>	$acc['username'],
							'password'			=>	$acc['password'],
							'user_boards'		=>	$acc['board_name'],
							'email'				=>	$acc['email'],
							'proxy'				=>	$acc['proxy'],
							'period'			=>	$sch['schedule']['period'],
							'keyword'			=>	$keyword,
							'type'				=>	$sch['schedule']['type'],
							'is_count_source'	=>	$is_count_source,
							'bitly_api_login'	=>	$acc['bitly_api_login'],
							'bitly_api_key'		=>	$acc['bitly_api_key'],
							'lang'				=>	$sch['schedule']['lang'],
							'board'				=>	$sch['boards'][array_rand($sch['boards'])],
							'template'			=>	$current_template,
							'params'			=>	$params
							);
	$time_random = rand(time(),(time()+(intval($sch['schedule']['period'])*60)));
	$date_time = date('Y-m-d H:i:s',$time_random);
	
	if(intval($sch['schedule']['rt_count'])>0){
		$file_data['rt_period'] = $sch['schedule']['rt_period'];
		$users = $sch['all_accounts'][0];
		shuffle($users);
		$array_chunks = array_chunk($users,$sch['schedule']['rt_count']);
		$temp_user = $array_chunks[0];
		if(count($temp_user)>0){
			//shuffle($temp_user);
			$file_data['rt_users'] = $temp_user;
		}
		else{
			//shuffle($users);
			$file_data['rt_users'] = $users;
		}
	}
	$array_thread[$thread_number][] = "('".serialize($file_data)."','".$date_time."',".$sch['schedule']['id'].")";
	$thread_number++;
}

$currentProcess = SITE_PATH."mass_schedular_db.php ".$implode_str;

$end_time = microtime();

echo "\n\n\n";
echo " End Time ";
echo "\n\n\n";
echo date('H:i:s');
echo "\n\n\n";

include_once('footer.php');




