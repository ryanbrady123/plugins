<?php 
	require_once(dirname(__FILE__)."/../config/configuration.php");
	require_once(SITE_PATH."classes/common.class.php");
	require_once(SITE_PATH."classes/accounts.class.php");
	require_once(SITE_PATH."classes/options.class.php");
	require_once(SITE_PATH."classes/emailapi.class.php");
	require_once(SITE_PATH."classes/pinterest.class.php");
	require_once(SITE_PATH."classes/mass_scheduler.class.php");
	require_once(SITE_PATH."classes/bitly.class.php");
	require_once(SITE_PATH."classes/emailapi.class.php");
	require_once(SITE_PATH."classes/simplepie.class.php");
	require_once(SITE_PATH."classes/unique.class.php");
	require_once(SITE_PATH."classes/simple_html_dom.php");
	require_once(SITE_PATH."classes/mass_follow.class.php");
	require_once(SITE_PATH."classes/mass_unfollow.class.php");
	
	/*
	require_once(SITE_PATH."classes/scheduletweets.class.php");
	require_once(SITE_PATH."classes/tweets.class.php");	
	require_once(SITE_PATH."classes/twitter.class.php");
	require_once(SITE_PATH."classes/unfollow.class.php");
	require_once(SITE_PATH."classes/follow.class.php");
	require_once(SITE_PATH."classes/lists.class.php");
	require_once(SITE_PATH."classes/decapcha/ccproto_client.php");*/
	
	class BasicFunctions{
		
		public $common, $bitly, $scheduleTweets, $tweets, $accounts, $twitter, $options,$lists,$db2,$simple_pie,$simple_html_dom;
		private $user_details;
		private $authnticity_token;
		private $proxy,$max_failure;
		
		
		function __construct() {
			global $db2;
			$common = new Common();
			//$bitly = new Bitly();
			//$scheduleTweets = new Scheduletweets();
			$options = new Options();
			$db2->connect();
			$this->db2 =& $db2;
			$this->proxy = '';
		}
		
		function __destruct() {
		  	$this->db2->close();
		}
		
		function update_code_field_error($acc,$field_name,$current_code,$error_code){		
			$accounts = new Accounts();
			$sql = '';
			if($acc[$field_name] == ($current_code+MAX_FAILURE)){
				$sql = $accounts->update_field_status($field_name,$error_code);
			}else{
				$sql = $accounts->update_field_status($field_name,$error_code+1);
			}
			$this->db2->execute($sql);
		}
		
		function authenticate($acc){
			$objPin = new Pinterest();
			$loggedScreenName = "";
			$auth_token = "";
			$html = $objPin->get_login_page($acc);
			$cookie_name =  strtolower($acc['username']);
			
			if(!empty($html) || !is_null($html)){
				$result = '';					
				$is_logged_in = $objPin->is_already_loggedin($html);
				if($is_logged_in){
					$auth_token = $objPin->get_auth_token($html);
					echo 'auth_token = '.$auth_token;
					return $auth_token;
				}
				else{
					$auth_token = $objPin->get_auth_token($html);
					$result = $objPin->make_login($acc,$auth_token);					
					if(empty($result)){
						$this->update_erros_codes($acc,'login_active',EMPTY_RESPONSE);
					}
					else{
						if($objPin->is_already_loggedin($result)){
							echo 'auth_token = '.$auth_token;
							return $auth_token;
						}
					}
				}
			}
			else{
				$this->update_erros_codes($acc,'login_active',EMPTY_RESPONSE);
				return false;
			}
			return false;
		}
		
		function post_pin($acc, $pin, $auth_token,$add_board = false,$is_repin = false){
			$objPin = new Pinterest();
			$loggedScreenName = "";
			
			if($add_board){
				// current boards
				$boards_and_cat = explode("||",trim($acc['board']));
				$board_all = explode(",",$boards_and_cat[0]);
				$cat_name = $boards_and_cat[1];
				$single_board = trim($board_all[array_rand($board_all,1)]);
				// user boards
				if(!empty($acc['user_boards'])){
					
					$this->db2->query("SELECT board_name FROM accounts where username  = '".$acc['username']."'");
					$user_boards = $this->db2->fetch_all_assoc();
					
					$user_boards = trim($user_boards[0]['board_name']);
					$temp_boards = explode("|??|",$user_boards);
					$user_boards = $temp_boards;
					$board_to_create = null;
					foreach($user_boards as $u_b){
						$u_b = trim($u_b);
						if(!empty($u_b)){
							$user_board_detail = explode("||",$u_b);
							if(strtolower(trim($user_board_detail[0])) == strtolower($single_board) && count($user_board_detail) == 3){
								echo "<br>Board Found In Accounts Table!";
								echo "<br>User = ".$acc['username'];
								echo "<br>Board Name = ".$single_board;
								echo "<br>Board Id = ".$user_board_detail[2];
								echo "<br>";
								$board_to_create['board_name'] = $single_board;
								$board_to_create['board_id'] = $user_board_detail[2];
								break;
							}
						}
					}
				}
				
				
				if(empty($board_to_create) && count($board_to_create) == 0){
					$board_to_create['board_name'] = $single_board;
					$board_to_create['cat_name'] = $cat_name;
					$board_res = $objPin->create_board($acc, $board_to_create, $auth_token);
					if($board_res['status'] == "success"){
						echo "<br>New Board Created!";
						echo "<br>Board Found In Accounts Table!";
						echo "<br>User = ".$acc['username'];
						echo "<br>Board Name = ".$board_to_create['board_name'];
						echo "<br>Board Id = ".$board_res['id'];
						echo "<br>";
						$board_to_create['board_id'] = $board_res['id'];
						$edit_board_str = "";
						if(empty($acc['user_boards'])){
							$edit_board_str = $single_board."||".$cat_name."||".$board_res['id'];
						}
						else{
							$edit_board_str = trim($acc['user_boards'])."|??|".$single_board."||".$cat_name."||".$board_res['id'];
						}
						echo "<br>";
						echo $sql = "UPDATE accounts SET board_name = '".$edit_board_str."' WHERE username = '".$acc['username']."'";
						echo "<br>";
						$this->db2->execute($sql);
					}
					else{
						echo "\n Create Board Failed !\n";
						echo "\n Board = ".$board_to_create['board_name']."\n";
						echo "\n User =  ".$acc['username']."\n";
					}
				}
				
				if(isset($board_to_create['board_id']) && !empty($board_to_create['board_id'])){
					$pin['board_id'] = $board_to_create['board_id'];
					if($is_repin){
						$pin_data = $objPin->get_repin_data($acc,$pin, $auth_token);
						$pin['pin_detail'] = $pin_data['details'];
						$response = $objPin->do_re_pin($acc, $pin, $auth_token);
						if($response['status'] == "success"){
							echo "\n Re-Pin Posted !\n";
							echo "\n Board = ".$board_to_create['board_name']."\n";
							echo "\n User =  ".$acc['username']."\n";
							//echo "\n URL =  http://pinterest.com/overmixercrisp".$response['url']."\n";
							return $response;
						}
						else{
							echo "\n Re-Pin Failed! \n";
							echo "\n Board = ".$board_to_create['board_name']."\n";
							echo "\n User =  ".$acc['username']."\n";
							echo "\n Error =  ".$response['message']."\n";
							return false;
						}
					}
					else{
						$response = $objPin->add_pin($acc, $pin, $auth_token);
						if($response['status'] == "success"){
							echo "\n Pin Posted !\n";
							echo "\n Board = ".$board_to_create['board_name']."\n";
							echo "\n User =  ".$acc['username']."\n";
							echo "\n URL =  http://pinterest.com".$response['url']."\n";
							return $response;
						}
						else{
							echo "\n Failed! \n";
							echo "\n Board = ".$board_to_create['board_name']."\n";
							echo "\n User =  ".$acc['username']."\n";
							echo "\n Error =  ".$response['message']."\n";
							return false;
						}
					}
				}
			}
			else{
				$html = $objPin->add_pin($acc, $pin, $auth_token);
				if($html['status'] == "success"){
					echo "\n Pin Posted !\n";
					echo "\n Board = ".$board_to_create['board_name']."\n";
					echo "\n User =  ".$acc['username']."\n";
					return $html;
				}
				else{
					echo "\n Failed! \n";
					echo "\n Board = ".$board_to_create['board_name']."\n";
					echo "\n User =  ".$acc['username']."\n";
					return false;
				}
			}
			return false;
						
		}
		
		function follow_multiple($acc, $follow, $auth_token){
			$objPin = new Pinterest();
			$loggedScreenName = "";
			$max_users = $follow['count'];
			$html_array = $objPin->search_user($acc, $follow);
			$reached_max = false;
			$all_users = array();
			foreach($html_array as $html){
				$users = $this->parse_users($acc,$html);
				if(count($all_users) < $max_users){
					foreach($users as $u){
						$all_users[] = $u;
						if(count($all_users) >= $max_users){
							$reached_max = true;
							break;
						}
					}
				}
				if($reached_max){
					break;
				}
			}
			unset($html_array);
			$success_users = array();
			if(count($all_users)>0){
				$url = "http://pinterest.com/search/people/?q=".$this->common->make_url($follow['params']);
				$this->common =  new Common();
				foreach($all_users as $user){
					$follow_result = json_decode($objPin->follow_user($acc,$user,$auth_token,$url),true);
					print_r($follow_result);
					if($follow_result['status'] == "success"){
						$success_users[] = $user;
					}
				}
			}
			return $success_users;
						
		}
		
		function follow_single($acc, $follow_user, $auth_token){
			$objPin = new Pinterest();
			$this->common =  new Common();
			$url = "http://pinterest.com/search/people/?q=".$this->common->make_url($acc['param']);
			
			$follow_result = json_decode($objPin->follow_user($acc,$follow_user,$auth_token,$url),true);
			if($follow_result['status'] == "success"){
				echo "\n Follow Success! ";
				echo "\n User = ".$acc['username'];
				echo "\n User to follow  = ".$follow_user;
				return true;
			}
			else{
				echo "\n Follow Failed! ";
				echo "\n User = ".$acc['username'];
				echo "\n User to follow  = ".$follow_user;
				echo "\n Message  = ".$follow_result['message'];
				return false;
			}
			return false;
		}
		
		function un_follow_single($acc, $follow_user, $auth_token){
			$objPin = new Pinterest();
			$this->common =  new Common();
			
			$follow_result = json_decode($objPin->un_follow_user($acc,$follow_user,$auth_token),true);
			print_r($follow_result);
			if($follow_result['status'] == "success"){
				echo "\n Un-Follow Success! ";
				echo "\n User = ".$acc['username'];
				echo "\n User to follow  = ".$follow_user;
				return true;
			}
			else{
				echo "\n Un-Follow Failed! ";
				echo "\n User = ".$acc['username'];
				echo "\n User to un-follow  = ".$follow_user;
				echo "\n Message  = ".$follow_result['message'];
				return false;
			}
			return false;
		}
		
		function search_users($acc,$follow,$keyword){
			$objPin = new Pinterest();
			$loggedScreenName = "";
			$max_users = $follow['count'];
			$html_array = $objPin->search_user($acc, $keyword);
			$reached_max = false;
			$all_users = array();
			foreach($html_array as $html){
				$users = $this->parse_users($acc,$html);
				if(count($all_users) < $max_users){
					foreach($users as $u){
						$all_users[] = $u;
						if(count($all_users) >= $max_users){
							$reached_max = true;
							break;
						}
					}
				}
				if($reached_max){
					break;
				}
			}
			unset($html_array);
			return $all_users;
						
		}
		
		function create_all_boards($acc, $auth_token){
			$objPin = new Pinterest();
			$board_detail = $this->separate_accounts_boards($acc['board_name']);
			if(!empty($board_detail)){
				$final_array = array();
				foreach($board_detail as $board){
					$board_info = $objPin->create_board($acc,$board,$auth_token);
					if($board_info['status'] == "success"){
						$final_array[] = $board['board_name']."||".$board['cat_name']."||".$board_info['id'];
					}
				}
			}
			if(!empty($final_array)){
				$all_boards_info = implode("|??|",$final_array);
				$sql = "UPDATE accounts SET pin_active = ".SUCCESS_CODE." ,board_active = ".SUCCESS_CODE.", board_name = '".$all_boards_info."' WHERE username = '".$acc['username']."'";
				$this->db2->execute($sql);
			}
			
			return $final_array;
		}
		
		function parse_users($acc,$html){
			$pattern = '/\<a class="ImgLink" href="(.*?)"\>\<img.*?src="(.*?)" \/\>/si';
			//<a class="ImgLink" href="/xeec83/"><img alt="Xee Chue" src="http://media-cdn.pinterest.com/avatars/xeec83_1330017852_o.jpg" /></a>
			preg_match_all($pattern,$html,$match);			
			$result = array();
			if(isset($match[1]) && count($match[1])>0){
				$this->common =  new Common();
				foreach($match[1] as $key => $m){
					$friend_name = strtolower(str_replace("/","",$m));
					$is_not_default = $this->common->checkDefaultImage($match[2][$key],$acc['username'],$friend_name);
					$db_user_not_exist = $this->check_user_not_exists($acc['username'],$friend_name);
					if($is_not_default && $db_user_not_exist){						
						$result[] = $friend_name;
					}
				}
			}
			return $result;
		}
		
		function check_user_not_exists($username,$follow_name){
			
			$this->common =  new Common();
			$table_info = $this->common->get_follow_table_name($username);

			echo $sql = "SELECT id,follow_name,status,date FROM follow_table_".$table_info['table_name']." WHERE username = '".$username."' AND follow_name = '".$follow_name."' LIMIT 1";
			$this->db2->query($sql);
			$user_exists_check = $this->db2->fetch_all_assoc();
			if(count($user_exists_check) == 0){
				echo "\n User Not in DB = ".$follow_name."    Username  = ".$username."\n";
				return true;
			}
			echo "\n User Already in DB = ".$follow_name."    Username  = ".$username."\n";
			return false;
		}
		
		function separate_accounts_boards($string){
			$array = explode("|??|",$string);
			$return_array = array();
			foreach($array as $arr){
				$temp = explode("||",$arr);
				$return_array[] = array('board_name' => $temp[0],'cat_name' => $temp[1]);
			}
			return $return_array;
		}
		
		
		function get_counts($acc){
			$objPin = new Pinterest();
			$html_result = $objPin->get_public_profile_page($acc);
			$result = array();
			if(!empty($html_result)){
				$html = new simple_html_dom();
				$html = null;	
				$html = str_get_html($html_result);
				
				$result['followers_count'] = intval(trim(str_replace("followers","",strip_tags($html->find('div[id=ContextBar] ul[class=follow] li a', 0)->innertext))));
				$result['following_count'] = intval(trim(str_replace("following","",strip_tags($html->find('div[id=ContextBar] ul[class=follow] li a', 1)->innertext))));
				$result['total_pages'] = ceil($result['followers_count']/50);
				$html->clear();
			}
			
			return $result;
		}
		
		function get_all_folower($acc,$page_count){
			$objPin = new Pinterest();
			$html_array = $objPin->get_all_followers($acc,$page_count);
			foreach($html_array as $html){
				$users = $this->parse_follow_page($html);
				foreach($users as $u){
					$all_users[] = $u;
				}
			}
			unset($html_array);
			
			return $all_users;
		}
		
		function parse_follow_page($page_html){
			$followers_list = array();
			$html = new simple_html_dom();
			$html = null;	
			$html = str_get_html($page_html);
			
			foreach($html->find('div[id=PeopleList] div[class=person]') as $g){
				$user_name = trim($g->find('div[class=PersonInfo] a', 0)->href);
				$followers_list[] = str_replace("/","",$user_name);
			}
			$html->clear();
			unset($page_html);
			return $followers_list;
		}
		
		
		
		
		
		
		/////////////////////////////////////////////////////////////////////////////////
		/////////////////////////////////////////////////////////////////////////////////
		/////////////////////////////////////////////////////////////////////////////////
		/////////////////////////////////////////////////////////////////////////////////
		
		
		
		
		
			
		function updateLoginStatus($username,$login_active,$error_code){		
			$accounts = new Accounts();
			$sql = '';
			$accounts->setUsername($username);
			if($login_active+1 == (150+$this->getMaxFailure())){
				$sql = $accounts->updateLoginActive($error_code);
			}else{
				$sql = $accounts->updateLoginActive($login_active+1);
			}
			$this->db2->execute($sql);
		}
		
		function update_erros_codes($acc,$field_name,$error_code){
			$obj_accounts = new Accounts();
			if($acc[$field_name]+1 == MAX_FAILURE){
				$sql = $obj_accounts->update_field_status($acc['username'],$field_name,$error_code);
			}else{
				$sql = $obj_accounts->update_field_status($acc['username'],$field_name,$acc[$field_name]+1);
			}
			$this->db2->execute($sql);
		}
		
		
		
		function updateTweetStatus($task_id, $status = 0){
			$tweets = new Tweets();
			$tweets->setId($task_id);
			$tweets->setStatus($status);
			$this->db2->execute($tweets->updateStatusByIds());
		}
		
		
		
		
		function updateTweetErrorCode($id,$date,$error_code){
			$tweets = new Tweets();
			$tweets->setId($id);
			$tweets->setPublishDate($date);
			$tweets->setErrorCode($error_code);//success
			$this->db2->execute($tweets->updateErrorCode());
		}
		
		function insertTweet($username,$content,$publish_date,$error_code,$schedule_id){
			$tweets = new Tweets();
			$tweets->setUsername($username);
			$tweets->setContent(addslashes($content));
			$tweets->setPublishDate($publish_date);
			$tweets->setErrorCode($error_code);
			$tweets->setScheduleId($schedule_id);
			//echo '<br>'.$tweets->insertTweetWithErrorCode();
			//echo '<br>';
			$this->db2->execute($tweets->insertTweetWithErrorCode());
			//$sql ="INSERT INTO ".$this->tableName."(username,content,publish_date,error_code,schedule_id) VALUES('".$this->getUsername()."','".$this->getContent()."','".$this->getPublishDate()."',".$this->getErrorCode().",".$this->getScheduleId().")";
		}
		function updateConsecFailure($id,$error_code){
			$scheduleTweets = new Scheduletweets();
			$scheduleTweets->setId($id);
			$this->db2->execute($scheduleTweets->updateConsecFailure($error_code));
		}
		
		function get_feeds($url,$proxy,$userrname,$type,$id,$file){
			$content = null;
			$this->common =  new Common();
			$simple_pie = new SimplePie();
			$cookie_name = $type."_".strtolower($userrname);
			$header_array = null;
			$user_agent = $this->common->get_user_agent();
			$proxy = $this->common->get_user_proxy();
			if($type == 'googleblogsearch' || $type == 'googleblogsearchcount'){
				$header_array[] = 'Host: www.google.com';
				$header_array[] = 'User-Agent: '.$user_agent;
				$header_array[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';
				//$header_array[] = 'Accept-Language: en-us,en;q=0.5';
				//$header_array[] = 'Accept-Encoding: gzip,deflate';
				//$header_array[] = 'Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7';
				$header_array[] = 'Connection: keep-alive';
				
				$content = $this->get_curl_results_source($url,$cookie_name,'http://www.google.com/',null,$proxy,$user_agent);
			}
			elseif($type == 'googlenews'  || $type == 'googlenewscount'){
				$header_array[] = 'Host: news.google.com';
				$header_array[] = 'User-Agent: '.$user_agent;
				//$header_array[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';
				//$header_array[] = 'Accept-Language: en-us,en;q=0.5';
				//$header_array[] = 'Accept-Encoding: gzip,deflate';
				//$header_array[] = 'Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7';
				$header_array[] = 'Connection: keep-alive';
				
				$content = $this->get_curl_results_source($url,$cookie_name,'http://www.google.com/',null,$proxy,$user_agent);
				
			}
			elseif($type == 'yahoonews'  || $type == 'yahoonewscount'){
				$header_array[] = 'Host: news.search.yahoo.com';
				$header_array[] = 'User-Agent: '.$user_agent;
				//$header_array[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';
				//$header_array[] = 'Accept-Language: en-us,en;q=0.5';
				//$header_array[] = 'Accept-Encoding: gzip,deflate';
				//$header_array[] = 'Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7';
				$header_array[] = 'Connection: keep-alive';
				
				$content = $this->get_curl_results_source($url,$cookie_name,'http://www.yahoo.com/',null,$proxy,$user_agent);
			}
			else{
				$content = $this->get_curl_results_source($url,$cookie_name,'',null,$proxy,$user_agent);
				//$content = $common->get_curl_results($url,null,false,null,null,null,$proxy);
			}
			
			$debug_text = "\n ------- ".$file." (XML) ------- \n";
			$debug_text .= "\n ID = ".$id;
			$debug_text .= "\n Type= ".$type;
			$debug_text .= "\n URL = ".$url;
			$debug_text .= "\n Result = ".$content;
			$this->common->saveDebugContent($userrname,$debug_text);
			
			if(trim($content) ==""){
					return "";
			}else{
				if($type == 'googleblogsearch' || $type == 'googleblogsearchcount'){
					$items = $content;
				}
				else{
					$simple_pie->set_raw_data($content);
					$simple_pie->init();
					$simple_pie->handle_content_type();
					$items = $simple_pie->get_items();
					
					$debug_text = "\n ------- ".$file." (After Parsing) ------- \n";
					$debug_text .= "\n ID = ".$id;
					$debug_text .= "\n Type= ".$type;
					$debug_text .= "\n URL = ".$url;
					$debug_text .= "\n Result= ".serialize($items);
					$this->common->saveDebugContent($userrname,$debug_text);
				}
				if(count($items)){
					return $items;
				}
				else{
					return null;
				}
			}
		}
		
		
		function get_curl_results_source($url,$cookie_name,$reffer,$header = array(),$currentProxy,$agent = "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.12) Gecko/20080201 Firefox/2.0.0.12") {
		echo $url;
        //$agent = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.12) Gecko/20080201 Firefox/2.0.0.12';
		//$agent = $this->getAgent();		
       	$cookie_file_path = SITE_PATH."cookies/".$cookie_name.'.txt';       
		if (!file_exists($cookie_name))
		{
            $fp = fopen($cookie_file_path, "wb");
            fclose($fp);
        }
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
		if (!is_null($header) || count($header)) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        }
		if(is_null($header)){
        	curl_setopt($ch, CURLOPT_USERAGENT, $agent);
		}
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT,REQUEST_TIMEOUT);
		curl_setopt($ch, CURLOPT_TIMEOUT,REQUEST_TIMEOUT);
		//curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
        
		$proxy = $currentProxy;
        if (!is_null($proxy) && $proxy !='') {
			//curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 1);
            curl_setopt($ch, CURLOPT_PROXY, $proxy);
        }
        curl_setopt($ch, CURLOPT_REFERER, $reffer);
       /* if (!empty($cookie_file_path)) {
            curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie_file_path);
            curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie_file_path);
        }*/
		
		
        $result = curl_exec($ch);
		if($result == false){			
			echo curl_error($ch);
			//$curlResult = $this->common->checkCurlResult(curl_error($ch),$proxy);
		}
		
		$info_array = curl_getinfo($ch);
        curl_close($ch);
       
        return $result;
    }
		
		
		
		function is_suspended($accounts_details,$username = ""){
			$accounts = new Accounts();
			$suspended = 0;
			if(array_key_exists('suspended',$accounts_details['requestCacheSeedData'][0]['json']['states'])){
			//if(isset($accounts_details['requestCacheSeedData'][0]['json']['states']['suspended'])){		
				$suspended = intval($accounts_details['requestCacheSeedData'][0]['json']['states']['suspended']);
			}
			/*else{
				$suspended = 1;
			}*/		
		
			if($suspended){
				$sql = $accounts->updateSuspended(-1,$username);// account is suspended
				$this->db2->execute($sql);
				return true;
			}
			else{
				return false;
			}
		}
		
	}
		

?>