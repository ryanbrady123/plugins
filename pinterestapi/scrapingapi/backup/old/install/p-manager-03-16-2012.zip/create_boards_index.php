<?php

	include_once('header.php');
	$threadCount = shell_exec("/bin/ps aux | /bin/grep '".SITE_PATH."create_boards.php' -c");
	//$threadCount = shell_exec("/bin/ps aux | /bin/grep '".SITE_PATH."mass_schedular.php' -c");
	//echo "\n Thread = ".$threadCount ."\n";
	if($threadCount<=2){
		$availableThread = $create_boards_threads;
	}
	else{
		$availableThread = $create_boards_threads-($threadCount-1);
	}

	//echo "\navailableThread = ".$availableThread;
	//echo "\n";
	
	$limit = $availableThread*$create_boards_tasks_per_thread;
	$db->query($objAccounts->get_active_accounts_for_baords("",$limit));
	$schedules = $db->fetch_all_assoc();
	$schedules_ids = array();
	if(count($schedules)>0){
		foreach($schedules as $sc){
			$schedules_ids[] = $sc['username'];
		}
		
		$all_ids = implode(",",$schedules_ids);
		
		$objMass_Schedular->setId($all_ids);
		$objMass_Schedular->setStatus(time());
		$db->execute("UPDATE accounts SET in_process = 1 WHERE username IN ('".implode("','",$schedules_ids)."')");
		//echo "\n schedules count = ".count($schedules);
		//echo "\n";
		$current_thread_count = ceil(count($schedules)/$availableThread);
		//echo "\n";
		$thread_chunks = array_chunk($schedules_ids,$current_thread_count);
		
		foreach($thread_chunks as $chunks){
			$threads = implode(",",$chunks);
			echo "/usr/bin/nohup  /usr/bin/php ".SITE_PATH."create_boards.php ".$threads;
			echo "\n\n";
			shell_exec("/usr/bin/nohup  /usr/bin/php ".SITE_PATH."create_boards.php ".$threads."  > /dev/null & echo $!");
		}
	}
$db->close();
