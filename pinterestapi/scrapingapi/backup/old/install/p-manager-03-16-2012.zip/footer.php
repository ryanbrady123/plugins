<?php 
	if(!empty($currentProcess)){
		$objCommon->killProcess($currentProcess);
	}
	echo 'done';
	$db->close();
	die();	

?>