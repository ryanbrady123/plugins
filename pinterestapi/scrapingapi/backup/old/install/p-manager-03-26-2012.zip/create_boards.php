<?php
include_once('header.php');

$allFollowersArray = array();
$allFollowingsArray = array();


unset($argv[0]);// to remove the first index which will be path of cron
$implodeStr = $argv[1];

if(isset($_GET['id'])){	
	$implodeStr = $_GET['id'];
}

$db->query($objAccounts->getAcccountsByUsername($implodeStr));
$accounts = $db->fetch_all_assoc();

$db->execute("UPDATE accounts SET in_process = 0 WHERE username IN ('".str_replace(",","','",$implodeStr)."')");

$start_time = microtime(true);//(round($usec, 2) + (float)$sec)
foreach ($accounts as $acc){
	$auth_token = $objBasicFunction->authenticate($acc);
	if($auth_token){
		$objBasicFunction->create_all_boards($acc,$auth_token);
	}
	$debug_text = "\n ------- Creation Finished ------- \n Total Time = ".((float)(microtime(true) - $start_time));
	$objCommon->saveDebugContent($acc['username'],$debug_text);
	
}

$currentProcess = SITE_PATH."create_accounts.php ".$implodeStr;

include_once('footer.php');
