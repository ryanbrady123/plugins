<?php

include_once('header.php');

unset($argv[0]);// to remove the first index which will be path of cron
$all_ids = $argv[1];

if(isset($_GET['id'])){
	$all_ids = $_GET['id'];
}

echo "<pre>";
echo "\n\n";
echo date('H:i:s');
echo "\n\n";


$start_time = date('Y-m-d H:i:s',time());
if(!empty($all_ids)){
	$db->query("SELECT * FROM follow WHERE id IN(".$all_ids.")");
	$all_follow = $db->fetch_all_assoc();
	foreach($all_follow as $follow){
		echo $objAccounts->get_active_accounts($follow['username']);
		$db->query($objAccounts->get_active_accounts($follow['username']));
		$user = $db->fetch_all_assoc();
		if(!empty($user[0])){			
			$auth_token = $objBasicFunction->authenticate($user[0]);
			if($auth_token){
				if($objBasicFunction->follow_multiple($user[0],$follow,$auth_token)){
					echo "\nPin Posted\n";
					echo "\nPin id =  ".$pin['id']."\n";
				}
			}
		}
	}
}



















	echo '<pre>';

	$start_time = date('Y-m-d H:i:s',time());
	$end_time = date('Y-m-d H:i:s',time()-($poster_minutes_to_process*60));
	
	echo "Query = ".$objMass_Schedular->get_content($thread_id,$start_time,$poster_minutes_to_process);
	
	$db->query($objMass_Schedular->get_content($thread_id,$start_time,$poster_minutes_to_process));
	$all_content = $db->fetch_all_assoc();
	
		$db->execute($objMass_Schedular->delete_content($thread_id,$start_time));
		$db->execute("OPTIMIZE TABLE thread_".$thread_id);
	
	echo "\n\n";
	echo "Total Records = ".count($all_content);
	echo "\n\n";
		
	foreach($all_content as $c){
		$out = preg_replace('!s:(\d+):"(.*?)";!se', "'s:'.strlen('$2').':\"$2\";'", $c['content']);
		$cnt = unserialize($out);
		print_r($cnt);
		
		if(isset($cnt['tweet_id'])){
			echo "\n Re-tweet by => ".$cnt['username'];
			echo "\n Tweet to => ".$cnt['tweet_user'];
			echo "\n Re-Tweet content => ".$cnt['content_to_post'];
			$re_tweet_response = postTweetAndRewteet($cnt['username'],$cnt['password'],$cnt['proxy'],null,$cnt['tweet_id']);
		}
		else{
			$params = array();	
			$url_result = null;
			$content_to_post = null;
			$template = $cnt['template'];
			$fs_title_keyword = '';
			if($cnt['type'] != 'basic' && $cnt['type'] != 'basic_account'){
				$url = str_replace(" ","+",$cnt['params']['simple_url']);
				$source_content = null;
				if($cnt['type'] == 'fs-title' || $cnt['type'] == 'fs-title-account'){
					
					if(isset($cnt['is_count_source']) && $cnt['is_count_source']){
						$source_content = $objCommon->get_cached_source($url);						
						$fs_title_keyword = str_replace(' ','+',$source_content['keyword']);
						$source_content = $source_content['content'];
					}
					if(is_null($source_content)){
						$url_result = $objCommon->get_curl_results($url,null,false,null,null,null,$cnt['proxy']);					
						$debug_text = "\n ------- Fast-site (Before Parsing) ------- \n";
						echo $debug_text .= "\n url = ".$url;
						$debug_text .= "\n Result = ".$url_result;
						$objCommon->saveDebugContent($cnt['username'],$debug_text);
						
						$source_content = json_decode($url_result,true);
						
						$debug_text = "\n ------- Fast-site (After Parsing) ------- \n";
						$debug_text .= "\n url = ".$url;
						$debug_text .= "\n Result= ".$url_result;
						$objCommon->saveDebugContent($cnt['username'],$debug_text);
						if(isset($cnt['is_count_source']) && $cnt['is_count_source']){
							$objCommon->store_cached_source($url,$source_content);							
						}
						$fs_title_keyword = str_replace(' ','+',$source_content['keyword']);
						$source_content = $source_content['content'];
					}
					
					
				}
				else{
					if(isset($cnt['is_count_source']) && $cnt['is_count_source']){
						$source_content = $objCommon->get_cached_source($url);
					}
					if(is_null($source_content)){
						$url = str_replace(" ","+",$cnt['params']['simple_url']);		
						if($cnt['type'] == 'amazon' || $cnt['type'] == 'amazoncount'){
							echo "\n\n";
							echo "URL = ".$url;
							echo "\n\n";
							$header_array[] = 'Host: www.amazon.com';
							$header_array[] = 'User-Agent: Mozilla/5.0 (Windows NT 6.1; rv:7.0.1) Gecko/20100101 Firefox/7.0.1';
							$header_array[] = 'Connection: keep-alive';
							$url_result = $objCommon->get_curl_results_source($url,"amazon_".$cnt['username'],'',$header_array,$cnt['proxy']);
							$debug_text = "\n ------- Amazon (Before Parsing) ------- \n";
							$debug_text .= "\n url = ".$url;
							$debug_text .= "\n Result= ".$url_result;
							$objCommon->saveDebugContent($cnt['username'],$debug_text);
							
							$source_content = $objCommon->amazonSearchContentFilter($url_result,5,$cnt['username']);
							$debug_text = "\n ------- Amazon (After Parsing) ------- \n";
							$debug_text .= "\n url = ".$url;
							$debug_text .= "\n Result= ".serialize($source_content);
							$objCommon->saveDebugContent($cnt['username'],$debug_text);
						}
						else{
							$Feeds = $objBasicFunction->get_feeds($url,$cnt['proxy'],$cnt['username'],$cnt['type'],$cnt['username'],"Rss for Poster");
							if($cnt['type'] == 'googleblogsearch' || $cnt['type'] == 'googleblogsearchcount'){
								$source_content = $objCommon->googleBlogSearchContentFilter($Feeds,5,$cnt['username']);
							}
							
							elseif($cnt['type'] == 'googlenews' || $cnt['type'] == 'googlenewscount'){						
								$source_content = $objCommon->googleNewsContentFilter($Feeds);
							}
							elseif($cnt['type'] == 'yahoonews' || $cnt['type'] == 'yahoonewscount'){
								$source_content = $objCommon->yahooNewsContentFilter($Feeds);
							}
							elseif($cnt['type'] == 'feed' || $cnt['type'] == 'delicious' || $cnt['type'] == 'surchur' || $cnt['type'] == 'feedcount' || $cnt['type'] == 'deliciouscount' || $cnt['type'] == 'surchurcount'){
								$source_content = $objCommon->feedContentFilter($Feeds);
							}
						
						}
						if(isset($cnt['is_count_source']) && $cnt['is_count_source']){
							$objCommon->store_cached_source($url,$source_content);							
						}						
					}
				}
				
				if(!isset($cnt['ended']) && isset($cnt['params']['user_count']) ){
						if($cnt['params']['user_count']>0){
							$params['simple_url'] = $url;
							$insert_sql = "INSERT INTO thread_".$thread_id." (content,publish_date,schedule_id) VALUES ";
							$all_templates = unserialize(file_get_contents(SITE_PATH.$scheduled_templates_folder_name."/".$cnt['params']['all_templates'].".parr"));	
							
							for($i=0;$i<$cnt['params']['user_count'];$i++){
								$c_template =$all_templates[array_rand($all_templates,1)];
								$r_u = array(	
											'username'			=>	$cnt['username'],
											'password'			=>	$cnt['password'],
											'proxy'				=>	$cnt['proxy'],
											'keyword'			=>	$cnt['keyword'],
											'is_count_source'	=>	$cnt['is_count_source'],
											'ended'				=>	1,
											'type'				=>	$cnt['type'],
											'bitly_api_login'	=>	$cnt['bitly_api_login'],
											'bitly_api_key'		=>	$cnt['bitly_api_key'],
											'lang'				=>	$cnt['lang'],
											'template'			=>	addslashes($c_template),
											'params'			=>	$params
											);
								$time_random = rand(time(),(intval(strtotime($c['publish_date'])+($cnt['period']*60))));
								$date_time = date('Y-m-d H:i:s',$time_random);
								$insert_sql .= "('".serialize($r_u)."','".$date_time."',".$c['schedule_id']."),";
							}
							$insert_sql = substr($insert_sql, 0, -1)."; ";
							if($cnt['params']['all_templates']==20){
								echo "\n\n\n";
								//echo $insert_sql;
								echo "\n\n\n";
							}
							$db->execute($insert_sql);
						}
						continue;
				}
				
				if($c['schedule_id'] == 22){
					echo "\n Result = ";
					print_r($source_content);
				}
				//echo "\n REplacing\n";
				// for title
				//echo "\n replaceTitle\n";
				$objCommon->replaceTitle($template,$source_content);
				// for description
				//echo "\n replaceDescription\n";
				$objCommon->replaceDescription($template,$source_content);
				
				if($cnt['type'] == 'amazon' || $cnt['type'] == 'amazoncount'){
					// for price
					$objCommon->replacePrice($template,$source_content);
					// for reviews
					$objCommon->replaceReviews($template,$source_content);
					// for rating
					$objCommon->replaceRating($template,$source_content);
					// for image
					$objCommon->replaceImage($template,$source_content);
					
				}
				
				/*echo "<br><br>";
				echo $template;
				echo "<br><br>";*/
				
				// for domain
				//echo "\n replacedomain\n";
				$template = str_replace('$domain$',$cnt['params']['fast_site_url'],$template);
				
				/*echo "<br><br>";
				echo $template;
				echo "<br><br>";*/
							
				// for keyword
				//echo "\n replacekeyword\n";
				$template = str_replace('$keyword$',str_replace(' ','+',$fs_title_keyword),$template);
				// replace url for sources
				//echo "\n replaceURL\n";
				if($cnt['type']!='fs-title' || $cnt['type']!='fs-title-account'){					
					$objCommon->replaceURL($template,$source_content);
				}
				// replace tags
				//echo "\n replaceTags\n";
				$objCommon->replaceTags($template,$source_content);
			}
			
			
			// for bitly
			//echo "\n replaceBitlyURL\n";
			$current_url = $objCommon->replaceBitlyURL($template,null,$cnt['proxy'],$cnt['bitly_api_login'],$cnt['bitly_api_key']);
			// for trim function 
			//echo "\n replaceTrim\n";
			$objCommon->replaceTrim($template,$current_url);
			//echo "\n replaceEmptyTrim\n";
			$objCommon->replaceEmptyTrim($template);
			//echo "\n replaceEmptyBilty\n";
			$objCommon->replaceEmptyBilty($template);
			//echo "\n replaceTrim\n";
			$objCommon->replaceTrim($template,$current_url);
			//echo "\n replaceBitlyURL\n";
			$content_to_post = trim($template);
			echo "\n\n Content = ".$content_to_post;			
			echo "\n\n";
			if(!is_null($content_to_post) && !empty($content_to_post)){
				$tweet_response = postTweetAndRewteet($cnt['username'],$cnt['password'],$cnt['proxy'],$content_to_post,0);
				$tweet_id = 0;
				if(isset($tweet_response->id)){
					$tweet_id = intval($tweet_response->id);
				}
				if(isset($cnt['rt_users']) && count($cnt['rt_users'])>0 && $tweet_id > 0){
					$insert_sql = "INSERT INTO thread_".$thread_id." (content,publish_date) VALUES ";		
					foreach($cnt['rt_users'] as $r_u){
						$r_u['tweet_id'] = $tweet_id;
						$r_u['tweet_user'] = $cnt['username'];
						$r_u['content_to_post'] = $content_to_post;
						$time_random = rand(time(),(time()+intval($cnt['rt_period']*60)));
						$date_time = date('Y-m-d H:i:s',$time_random);
						$insert_sql .= "('".serialize($r_u)."','".$date_time."'),";
						//$re_tweet_response = postTweetAndRewteet($r_u['username'],$r_u['password'],$r_u['proxy'],null,$tweet_id);
					}
					$insert_sql = substr($insert_sql, 0, -1)."; ";
					$db->execute($insert_sql);
				}
				
			}			
		}
		

	}
	
	function postTweetAndRewteet($user,$pass,$proxy,$content = '',$tweet_id = 0){
		$tweetResponse = array();	
		$flag = 0;		
		global $objCommon, $objBitly, $objScheduleTweets, $objTweets, $objOptions, $objAccounts, $objTwitter, $objBasicFunction, $db;		
		$loggedScreenName = '';		
		$currentProxy = $proxy;
		$cookie_name = $user;
		
		$twitterLoginResult = $objTwitter->getLoginPage($currentProxy,$cookie_name);		
		$loggedScreenName = $objBasicFunction->authenticate($user,$pass,$twitterLoginResult,$cookie_name);		
		if(!empty($loggedScreenName)){
			$objAccounts->setUsername($user);
			$accounts_details = $objTwitter->getAccountDetail($user);
			$userId = intval($accounts_details['requestCacheSeedData'][0]['json']['id_str']);
			if($userId){
				$suspended = $objBasicFunction->is_suspended($accounts_details,$user);
				if(!$suspended){
					echo "\n Auth Token = ".$accounts_details['postAuthenticityToken']."\n";
					$objTwitter->setGolbalAuthToken($accounts_details['postAuthenticityToken']);
					if($tweet_id == 0){	
						$tweetResponse = $objTwitter->doTweet($loggedScreenName,$content);
						echo "\n Tweet REsponse = ".serialize($tweetResponse)."\n";
					}
					else{
						$tweetResponse = $objTwitter->doReTweet($loggedScreenName,$tweet_id);
					}
				}
			}
		}
		
		if(isset($tweetResponse->retweeted_status->id)){
				echo "\n Posted => ".$user;
				echo "\n Tweet-id => ".$tweet_id;
		}
		elseif(isset($tweetResponse->errors)){
			echo "\n Failed!\n ";
			echo "\n Error = ".$tweetResponse->errors."\n";
			print_r($tweetResponse->errors);
		}
		elseif(isset($tweetResponse->error)){
			echo "\n Failed!\n ";
			echo "\n Error = ".$tweetResponse->error."\n";
		}
		elseif(empty($tweetResponse)){
			echo "\n Failed!\n ";
			echo "\n Error = ".$tweetResponse->error."\n";
		}
		else{
				echo "\n Posted => ".$user;
				echo "\n Content => ".$content." \n ";
			}
		
		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//print_r($tweetResponse);
		return $tweetResponse;
	
	}

$currentProcess = SITE_PATH."poster_db.php ".$thread_id;

echo "\n\n\n";
echo " End Time ";
echo "\n\n\n";
echo date('H:i:s');
echo "\n\n\n";

include_once('footer.php');


