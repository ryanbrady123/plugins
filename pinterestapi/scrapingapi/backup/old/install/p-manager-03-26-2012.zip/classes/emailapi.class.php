<?php

class EmailAPI extends Common{
 

    public function emailAPI() {
    }
	public function confirmEmail($postData = array(),$url,$username,$password){
		$start_time = microtime(true);
		$postingData = 'content='.json_encode($postData);
		
		$ch = curl_init(); 
		curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_POST      ,1);
		curl_setopt($ch, CURLOPT_POSTFIELDS , $postingData);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		
		curl_setopt($ch, CURLOPT_USERPWD, $username . ':' . $password);
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
		
		//curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie_file_path);
		//curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie_file_path);
		$result = curl_exec ($ch);
		curl_close ($ch); 
			
		//$result = json_decode(parent::get_curl_results($url, $postingData,false,'',null,0,'',CONFIRM_EMAIL_API_USER,CONFIRM_EMAIL_API_PASS),1);
		$result_array = json_decode($result,1);
		$debug_text = "\n ------ Get Email From Aggregator -------\n Process Time =  ".((float)(microtime(true) - $start_time));
	    $debug_text .= "\n Result = ".serialize($result_array);
		parent::saveDebugContent($username,$debug_text);
		
		return $result_array;
	}
	
	

}

?>