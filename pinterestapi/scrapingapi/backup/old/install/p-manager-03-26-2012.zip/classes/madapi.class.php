<?php
/**
(*x-y||text1||text2||text3||text4||text5||text6*) = pick randomly x to y of the text strings
[*text1||text2||text3*] = randomly order all of them
{*text1,text2,text3*} = randomly select 1 of the strings
$keyword$ = use synonym builder call
**/

class madapi{
    
    public $template;
    
    public $products;
    
    /**
     *Reads a template from file(full path must be provided or relative to script) 
     */
    public function fromFile($file = null){
        if(file_exists($file)){
        	$this->template    = file_get_contents($file);
            return true;
        }
        else return false;
    }
    
    public function fromString($template = ''){
    	$this->template	= $template;
    }
    
    public function getSynonym($keyword = null){
    }
    
    /**
     * Identify part of speach
     */    
    public function pos($keyword){
    } 

    /**
     * Generate products based on the template
     */
    public function produce($count = 1){
		
		
		//fix for special characters
        $altered    		= htmlspecialchars_decode($this->template, ENT_QUOTES);
       // $cleaner_pattern	= '/[^A-Za-z\s0-9 \.,\?\'""!@#\$%\^&\*\(\)-_=\+;:<>\/\\\|\}\{\[\]`~]+/';
        //$altered			= preg_replace($cleaner_pattern, '', $altered);
		
		//echo "<br><br>=======================================================================<br><br>";

        //$cleaner_pattern	= '/[\w]+(\*)[\w]+/';
        //$altered			= preg_replace($cleaner_pattern, ' ', $altered);		
		//exit;

        
        //failsafe for cases when a replacement is not possible for some crazy reason
        $max_tries	= 20;
         
        $tries		= 0;    
        while(strpos($altered, '{*')!==FALSE && $tries<$max_tries){
            $patern    = '/\{\*(.*?)\*\}/si';
			//$patern     = '/\{\*([a-zA-Z\s0-9,-<>!\|\'\$]+)\*\}/';
            //$patern     = '/\{\*([A-Za-z\s0-9 \.,\?\'""!@#\$%\^&\*\(\)-_=\+;:<>\/\\\|\}\{\[\]`~]+)\*\}/';
            $matches = array();
			preg_match_all($patern, $altered, $matches);
			$altered = replace_patern_new($matches,$altered);
			
			//$altered    = preg_replace_callback($patern, "replace_patern", $altered);
            $tries++;
        }
		$tries		= 0;
        while(strpos($altered, '[*')!==FALSE && $tries<$max_tries){
            $patern    = '/\[\*(.*?)\*\]/si';
			//$patern    = '/\[\*([a-zA-Z\s0-9,-<>!\|\'\$]+)\*\]/';
            //$patern    = '/\[\*([A-Za-z\s0-9 \.,\?\'""!@#\$%\^&\*\(\)-_=\+;:<>\/\\\|\}\{\[\]`~]+)\*\]/';
            //$altered   = preg_replace_callback($patern, "order_patern", $altered);
			$matches = array();
			preg_match_all($patern, $altered, $matches);
			$altered = order_patern_new($matches,$altered);
            $tries++;
        }
		$tries		= 0;        
        while(strpos($altered, '(*')!==FALSE && $tries<$max_tries){
            $patern    = '/\(\*(.*?)\*\)/si';
			//$patern    = '/\(\*([a-zA-Z\s0-9,-<>!\|\'\"\#\;\:\~\`\$\&\+\%\)\()\]\[\{\}\?@_]+)\*\)/si';
            //$patern    = '/\(\*([A-Za-z\s0-9 \.,\?\'""!@#\$%\^&\*\(\)-_=\+;:<>\/\\\|\}\{\[\]`~]+)\*\)/';
            //$patern    = '/[\(\*]([\W\w])+[\*\)]/';
			$matches = array();
			preg_match_all($patern, $altered, $matches);
			$altered = pick_patern_new($matches,$altered);
            //$altered   = preg_replace_callback($patern, "pick_patern", $altered);
            $tries++;
        }
		
		return $altered;
		
/*
        $this->products[]=$altered;
        //die($altered);
        if($count==1)return $this->products;
        else{
        	return $this->produce($count-1);
        }*/
    }
}
    /*
     * {*text1||text2||text3*} = randomly select 1 of the strings
     */
    function replace_patern($matches){
        //var_dump($matches);die;
        $available_parts = explode('||', $matches[1]);
        return $available_parts[array_rand($available_parts)];
    }
	
	function replace_patern_new($matches,$altered){
		if(count($matches[1])>0){
			foreach($matches[1] as $key=>$mt){
				$available_parts = explode('||', $mt);
				$implode = $available_parts[array_rand($available_parts)];
				$altered = str_replace($matches[0][$key],$implode,$altered);
			}
		}
		return $altered;
    }  
    
    /*
     * [*text1||text2||text3*] = randomly order all of them
     */
    function order_patern($matches){
        $available_parts = explode('||', $matches[1]);
        shuffle($available_parts);
        return implode('', $available_parts);
    }  
	
	function order_patern_new($matches,$altered){
		if(count($matches[1])>0){
			foreach($matches[1] as $key=>$mt){				
				$available_parts = explode('||', $mt);
				shuffle($available_parts);
				$implode = implode('', $available_parts);
				$altered = str_replace($matches[0][$key],$implode,$altered);
			}
		}
		return $altered;
    }

    /*
     * (*x-y||text1||text2||text3||text4||text5||text6*) = pick randomly x to y
     * of the text strings
     */
    function pick_patern($matches){
        $available_parts = explode('||', $matches[1]);
     /*  	echo "<pre>";
	    print '<br/>matches:<br/>';
        print_r($matches);
        print '<br/>parts:';
        print_r($available_parts).'<br>';*/
        $limits          = explode('-', $available_parts[0]);
        //print_r($limits);die;
        unset($available_parts[0]);
        $items_to_pick   = rand($limits[0], $limits[1]);
        //print '('.$limits[0].'++'.$limits[1].')pic:'.$items_to_pick; 
        //$items_to_unset  = count($available_parts) - $items_to_pick;
        //print $items_to_unset;die;  
        $picked	= array();
        for($i=0;$i<$items_to_pick;$i++){
            $idx		= array_rand($available_parts);
            $picked[]	= $available_parts[$idx]; 
            unset($available_parts[$idx]);        	
        }
        shuffle($picked);
        //echo 'returning:<br/>';
        //print_r($picked);
        //echo '<br/><br/>';
        return implode('', $picked);
    }
	
	function pick_patern_new($matches,$altered){
		if(count($matches[1])>0){
			foreach($matches[1] as $key=>$mt){
				$available_parts = explode('||', $mt);
				$limits = explode('-', $available_parts[0]);
				unset($available_parts[0]);
				$items_to_pick   = rand($limits[0], $limits[1]);
				$picked	= array();
				for($i=0;$i<$items_to_pick;$i++){
					$idx		= array_rand($available_parts);
					$picked[]	= $available_parts[$idx]; 
					unset($available_parts[$idx]);        	
				}
				shuffle($picked);
				$implode = implode('', $picked);				
				$altered = str_replace($matches[0][$key],$implode,$altered);
			}
		}
		return $altered;
    }
	
	

?>