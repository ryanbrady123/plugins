<?php
include_once('header.php');

$allFollowersArray = array();
$allFollowingsArray = array();


unset($argv[0]);// to remove the first index which will be path of cron
$implodeStr = $argv[1];


if(isset($_GET['user'])){	
	$implodeStr = $_GET['user'];
}


$db->query($objAccounts->getAcccountsByUsername($implodeStr));

$accounts = $db->fetch_all_assoc();

$start_time = microtime(true);//(round($usec, 2) + (float)$sec)
foreach ($accounts as $acc){
	$file = SITE_PATH.'createlog/';
	$error = '';
	$debug_text = '';
	$date = date('Y-m-d H:i:s');
	

	$post_where['to_email']['value'] = $acc['email'];
	$post_where['to_email']['operator'] = 'exact';	 
	
	$post_where['from_domain']['value'] = 'pinterest.com' ;
	$post_where['from_domain']['operator'] = 'like' ;
	 
	$post_where['subject']['value'] = 'Check out my stuff on Pinterest' ;
	$post_where['subject']['operator'] = 'like' ;
	$apiresult = $objEmailAPI->confirmEmail($post_where,$confirm_email_api_url,$confirm_email_api_username,$confirm_email_api_password);
	
	if(!empty($apiresult[0]['html_content'])){
		$apiresult[0]['html_content'];
		
		foreach($apiresult as $api){
			$html = $api['html_content'];
			$pattern = '/\>http:\/\/pinterest.com\/invited\/\?email=(.*?)\<\/a\>/si';
			//$patterbn = "/<a href="http://email.pinterest.com/wf/click?upn=gtVgPMyop82oL44zySHqvq-2FjWlTWZzvHeAQD9TiiWl34GxdvBAjt97vOH1weB-2BP8Yfk-2FdpL-2FXn4fZfiUbH0i3PhKxxlDLIz7VNSk9-2FT6IZ9QlmqV2XTjl8OTduANwXXxfTPb0hhx06yJ5mCORMWyqYaHo1lSYrNj5fujn9hNU0TMFpL5ZKpHh4edfuTsEeahQgljpY-2Be-2BXaU7Kxr9i40Jg-3D-3D_8CZIdLciSFC-2BO5jF-2FiP8qNWm7-2BvFYBqmAtWzrdhTNirb4PGmOia8b0kxe-2FRuoLmx2POyL6XUHmyXs4lfjLmAAtdX9T6XNgxvX-2FwV-2BMjtxD-2BdEn3SvDfqRRRUHJK-2Fl1VzLZBf3ryr3BYhZJZSmoy3KkB-2Bk7TgQDXvCJG-2BBdXKwEMyU20KBuHfbBCKAysgh1pDIYXRqIjfTE6wXCF3ba4hxA-3D-3D" style="color: rgb(203, 32, 39); text-decoration: none;" target="_blank">/si"
			preg_match_all($pattern,$html,$match);
			$redirect_after_login = '';
			$loggedScreenName = '';
			
			if(isset($match[1][0]) && !empty($match[1][0])){
				echo $redirect_after_login = 'http://pinterest.com/invited/?email='.trim(strip_tags($match[1][0]));
				
				$cookie_name = strtolower($acc['username'].'-twitter');
				/*$twitterLoginResult = $objTwitter->getLoginPage($acc);
				if(empty($twitterLoginResult)){
					$db->execute($objAccounts->update_field_status($acc['username'],'login_active',PROXY_ERROR));
					continue;
				}*/
				
				$confirmResult = $objPinterest->authenticate_with_twitter($acc,$redirect_after_login);
				
				//$pattern = '/\>http:\/\/pinterest.com\/invited\/\?email=(.*?)\<\/a\>/si';
				$pattern = '/\<a href="http:\/\/pinterest.com\/twitter\/\?oauth_token=(.*?)"/si';
	
				
				preg_match_all($pattern,$confirmResult,$match);
				$pin_twitter_url = "";
				$signup_result = "";
				if(isset($match[1][0]) && !empty($match[1][0])){
					$pin_twitter_url = trim(strip_tags($match[1][0]));
					$signup_result = $objPinterest->get_signup_page($acc,$pin_twitter_url);
					
					unset($confirmResult);
					
					$url_tokens = explode("&",$redirect_after_login);
					echo '<pre>';
					print_r($url_tokens);
					$invite = str_replace("invite=","",$url_tokens[1]);
					
					$csrf_token = $objPinterest->get_auth_token($signup_result);
					
					unset($signup_result);
					
					$create_result = $objPinterest->create_account($acc,$invite,$csrf_token);
					
					echo "<br> ================  create_account ============= <br> ";
					echo '<textarea cols="100" rows="50" id="active">'.$create_result.'</textarea>';
	
					if(strpos(strtolower($create_result),strtolower("Click a few things you like so we can suggest people to follow")) !== false){
						echo $sql = "UPDATE accounts SET created = 200 , send_request = 200 WHERE username = '".$acc['username']."'";
						$db->execute($sql);
					}
					else{
						$objBasicFunction->update_code_field_error($acc,'created',$acc['created'],UNKNOWN_RESPONSE_ERROR);
					}
				}
				else{
					$objBasicFunction->update_code_field_error($acc,'created',$acc['created'],TWITTER_AUTH_FAILED);
				}
				
				

				
				/*$loggedScreenName = $objBasicFunction->authenticate_twitter($acc);
				if (empty($loggedScreenName)) {
					$db->execute($objAccounts->update_field_status($acc['username'],'login_active',LOGIN_FAILED_ERROR));
				}
				
				if(!empty($loggedScreenName)){
					// Change login_active
					$db->execute($objAccounts->update_field_status($acc['username'],'login_active',0));
					$suspended = 0;
					$accounts_details = $objTwitter->getAccountDetail($acc['username']);
					$objTwitter->setGolbalAuthToken($accounts_details['postAuthenticityToken']);
					$suspended = $objBasicFunction->is_suspended($accounts_details,$acc['username']);
					if($suspended){
						$db->execute($objAccounts->update_field_status($acc['username'],'suspended',-1));// account is suspended
						continue;
					}
					echo "<br> Loged USer = ";
					echo $loggedScreenName;
					echo "<br>";
					$confirmResult = $objPinterest->authenticate_with_twitter($acc,$redirect_after_login);
					
				}
			*/
			
				
					
				/*if(!empty($loggedScreenName)){
					echo "<br><br><br>";
					echo $loggedScreenName;
					echo "<br><br><br>";
					
					$confirmResult = $objPinterest->authenticate_with_twitter($acc,$redirect_after_login);
					
					exit;
					$pattern = 'Your account has been confirmed. Thanks!';
					$pos = strpos(strtolower($confirmResult),strtolower($pattern));
				
					//if($pos !== false){
						$db->execute($objAccounts->updateLoginActive(0));
						$db->execute("UPDATE accounts SET login_active = 0 WHERE username  = '".$acc['username']."'");
						$current_error_code = '0 (Confirmed)';
						//}
				}
				else{
					$time = date('Y-m-d H:i:s',time()+($confirm_email_time*60));// addding minutes for confirm email address to work
					$db->execute("UPDATE accounts SET last_run = '".$time."' WHERE username  = '".$acc['username']."'");
				}*/
			}
			else{
				$objAccounts->setUsername($acc['username']);
				$objAccounts->setLastRun(time()+($confirm_email_time*60));// addding minutes for confirm email address to work
				$db->execute($objAccounts->updateLastRun());
			}
		}
	}
	
	$db->execute($objAccounts->update_field_status($acc['username'],'in_process',0));	
	
	$debug_text = "\n ------- Creation Finished ------- \n Total Time = ".((float)(microtime(true) - $start_time));
	$objCommon->saveDebugContent($acc['username'],$debug_text);
	
}

$currentProcess = SITE_PATH."create_accounts.php ".$implodeStr;

include_once('footer.php');
