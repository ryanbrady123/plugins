<?php

include_once('header.php');

define('UN_FOLLOW_THREADS',$mass_un_follow_threads);


unset($argv[0]);// to remove the first index which will be path of cron
$implode_str = $argv[1];

if(isset($_GET['id'])){
	$implode_str = $_GET['id'];
}
echo "\n\n";
echo date('H:i:s');
echo "\n\n";

echo '<pre>';
echo $objMass_Un_Follow->getRecordsById($implode_str);
$db->query($objMass_Un_Follow->getRecordsById($implode_str));
$schedules = $db->fetch_all_assoc();

$thread_number = 1;
$array_thread = array();


$complete_array = array();
$count_files = 0;

foreach($schedules as $sch){
	$accounts_all = array();
	echo $objAccounts->getAccountByNotesForMassUnfollow($sch['notes']);
	$db->query($objAccounts->getAccountByNotesForMassUnfollow($sch['notes']));
	$accounts = $db->fetch_all_assoc();
	
	echo " <br> Total Acvcounts = ".count($accounts);
	echo "<br>";
	
	if(intval($thread_number) > UN_FOLLOW_THREADS){
		$thread_number = 1;
	}
	if(count($accounts)>0){
		foreach($accounts as $acc){
			if(intval($thread_number) > UN_FOLLOW_THREADS){
				$thread_number = 1;
			}
			$keywords = addslashes($acc['keywords']);
			$file_data = array(	
								'username'			=>	strtolower($acc['username']),
								'email'				=>	strtolower($acc['email']),
								'password'			=>	$acc['password'],
								'proxy'				=>	$acc['proxy'],
								'all_unfollow'		=>	$sch['all_unfollow'],
								'days_in_past'		=>	$sch['days_in_past'],
								'count'				=>	$sch['count'],
								'period'			=>	$sch['period']
								);
			$time_random = rand(time(),(time()+(intval($sch['period'])*60)));
			$date_time = date('Y-m-d H:i:s',$time_random);	
			$array_thread[$thread_number][] = "('".serialize($file_data)."' , '".$date_time."',".$sch['id'].")";
			$thread_number++;
		}
	}
	
	$next_run_temp = time()+(intval($sch['period'])*60);
	$next_run = date('Y-m-d H:i:s',$next_run_temp);
	echo "UPDATE unfollow_scheduler SET next_run = '".$next_run."' , status = 0 WHERE id = ".$sch['id'];
	$db->execute("UPDATE unfollow_scheduler SET next_run = '".$next_run."' , status = 0 WHERE id = ".$sch['id']);
}

/// Execute Queries
foreach($array_thread as $key=>$th){
	$insert_sql = "";
	$db->execute($objMass_Un_Follow->create_table($key));
	$insert_sql = "INSERT INTO un_follow_thread_".$key." (content,publish_date,schedule_id) VALUES ".implode(",",$th);
	
	//$insert_sql = substr($th, 0, -1)."; ";
	$result = $db->execute($insert_sql);	
}

$currentProcess = SITE_PATH."unfollow_mass_scheduler_db.php ".$implode_str;

$end_time = microtime();

echo "\n\n\n";
echo " End Time ";
echo "\n\n\n";
echo date('H:i:s');
echo "\n\n\n";

include_once('footer.php');




