<?php

class Accounts extends Common{

	private $tableName;


    function Accounts() {
        $this->tableName = "accounts";
    }
	
	public function listAccountsToBeRequested($limit) {
       $sql = 'SELECT * FROM '.$this->tableName.' WHERE ((send_request >= 100  AND send_request <= '.(100+MAX_FAILURE).') OR (send_request = 150 AND created = 200 AND login_active >= 0 AND login_active <= '.MAX_FAILURE.')) AND last_run <= NOW() AND create_date <= NOW() AND in_process = 0 ORDER BY last_run ASC  LIMIT '.$limit;
       return $sql;
    }
	
	public function listAccountsToBeCreated($limit) {
       echo $sql = 'SELECT * FROM '.$this->tableName.' WHERE (created >= 100 AND created <= '.(100+MAX_FAILURE).') AND send_request = 200 AND last_run <= NOW() AND in_process = 0 ORDER BY last_run ASC  LIMIT '.$limit;
	   echo '<br>';
       return $sql;
    }
	
	/*public function listAccountsToBeCreated($limit) {
       echo $sql = 'SELECT * FROM '.$this->tableName.' WHERE (send_request >= 200  AND send_request <= '.(200+MAX_FAILURE).') AND (created >= 100 AND created <= '.(100+MAX_FAILURE).') AND last_run <= NOW() AND in_process = 0 ORDER BY last_run ASC  LIMIT '.$limit;
	   echo '<br>';
       return $sql;
    }*/
	
	public function listAccountsForInvitation($limit) {
       echo $sql = 'SELECT * FROM '.$this->tableName.' WHERE send_request >= 0 AND  send_request <= '.MAX_FAILURE.' AND created = 0 AND in_process = 0 ORDER BY create_date ASC  LIMIT '.$limit;
	   echo '<br>';
       return $sql;
    }
	
	 public function updateInProcess($usernames,$in_process = 0){
		$all_users = implode("','",$usernames);
		echo $sql = "UPDATE ".$this->tableName." SET in_process = " .$in_process. " WHERE  username IN('".$all_users."')";
		echo '<br>';
		return $sql;
	}
	
	 public function getAcccountsByUsername($usernames){
		if(is_array($usernames)){
			$all_users = implode("','",$usernames);
		}
		else{
			$all_users = str_replace(",","','",$usernames);
		}
		echo $sql = "SELECT  * FROM ".$this->tableName." WHERE  username IN('".$all_users."')";
		echo '<br>';
		return $sql;
	}
	
	public function sql_account_got_request($username){
		$time = date('Y-m-d H:i:s',time()+(CHECK_EMAIL_TIME *60 ));
		echo $sql = "UPDATE ".$this->tableName." SET send_request = 200 , created = 100, last_run = '".$time."' WHERE  username = '".$username."' ";
		echo '<br>';
		return $sql;
		
	}
	
	public function update_field_status($username,$field_name,$code){
		echo $sql = "UPDATE ".$this->tableName." SET ".$field_name." = ".$code." WHERE username = '".$username."'";
		echo '<br>';
		return $sql;
	}
	
	public function get_active_accounts($username = "", $limit = ""){
		$sql = "SELECT * FROM accounts WHERE created = ".SUCCESS_CODE." AND suspended = 0 AND login_active >= 0 AND login_active <= ".MAX_FAILURE;
		
		if(!empty($username)){
			$sql .= " AND username = '".trim($username)."'";
		}
		if(!empty($limit)){
			$sql .= " LIMIT ".$limit;
		}
		return $sql;
	}
	
	public function get_active_accounts_for_baords($username = "", $limit = ""){
		$sql = "SELECT * FROM accounts WHERE created = ".SUCCESS_CODE." AND suspended = 0 AND board_active = 0 AND login_active >= 0 AND login_active <= ".MAX_FAILURE;
		
		if(!empty($username)){
			$sql .= " AND username = '".trim($username)."'";
		}
		if(!empty($limit)){
			$sql .= " LIMIT ".$limit;
		}
		return $sql;
	}
	
	// For Mass Schdular 
	public function getAccountByNotesForMass($notes)
	{
		$notes = str_replace(",","','",$notes);
		$sql = "SELECT username, password,email,site,feed_url_list,bitly_api_login,bitly_api_key,proxy,keywords,follow_keywords,board_name,login_active FROM ".$this->tableName."  WHERE created = 200 AND login_active >= 0 AND login_active < ".MAX_FAILURE." AND board_active =".SUCCESS_CODE." AND pin_active = ".SUCCESS_CODE."  AND suspended = 0  AND note IN('".$notes."') ORDER BY rand() ";
       	return $sql;
	}
	// For Mass Schdular Unfollow
	public function getAccountByNotesForMassfollow($notes)
	{
		$notes = str_replace(",","','",$notes);
		$sql = "SELECT username,password,email,site,bitly_api_login,bitly_api_key,proxy,keywords,follow_keywords FROM ".$this->tableName."  WHERE created = 200 AND login_active >= 0 AND login_active < ".MAX_FAILURE." AND follow_active = 200 AND suspended = 0  AND note IN('".$notes."') ORDER BY rand() ";
       	return $sql;
	}
	// For Mass Schdular Unfollow 
	public function getAccountByNotesForMassUnfollow($notes)
	{	
		$notes = str_replace(",","','",$notes);
		$sql = "SELECT username, password,email,site,bitly_api_login,bitly_api_key,proxy,keywords,follow_keywords FROM ".$this->tableName."  WHERE created = 200 AND login_active >= 0 AND login_active < ".MAX_FAILURE." AND unfollow_active = 200 AND suspended = 0  AND note IN('".$notes."') ORDER BY rand() ";
       	return $sql;
	}
	public function getUsernamesByNotes($max_failure,$limit = 10)
	{
		$notes = str_replace(",","','",$this->getNote());
		$sql = "SELECT username, password FROM accounts  WHERE created = 200 AND login_active >= 0 AND login_active < ".$max_failure." AND tweet_active >= 0 AND tweet_active < ".$max_failure."  AND suspended = 0  AND note IN('".$notes."') ORDER BY rand() LIMIT ".$limit;
       	return $sql;
	}
	
	public function listAccountsForDownloadImages($limit) {
       $sql = 'SELECT username FROM '.$this->tableName.' WHERE (update_image = 100  OR update_image = 150)  AND created = 200 AND login_active >= 0 AND login_active < '.MAX_FAILURE.' AND suspended = 0 ORDER BY last_run ASC LIMIT '.$limit;
	   return $sql;
    }
	
	public function updateProfileAndImage($status,$username,$image = "") {
       $sql = " UPDATE ".$this->tableName." SET update_image = ".$status. " , image_path = '".$image."' WHERE username = '".$username."' ";
       return $sql;
    }
	
	public function updateUpdateImages($status,$username) {
       $sql = " UPDATE ".$this->tableName." SET update_image = ".$status. " WHERE username = '".$username."' ";
       return $sql;
    }
	
	public function listAccountsForUpdate($limit) {
       $sql = 'SELECT * FROM '.$this->tableName.' WHERE ((update_profile >= 0  AND update_profile < '.MAX_FAILURE.') OR (update_image >= 0 AND update_image < '.MAX_FAILURE.')) AND created = 200 AND login_active >= 0 AND login_active < '.MAX_FAILURE.' AND suspended = 0 ORDER BY last_run ASC LIMIT '.$limit;
	   return $sql;
    }
	
	
}

?>