<?php

include_once('header.php');

unset($argv[0]);// to remove the first index which will be path of cron
$implodeStr = $argv[1];

if(isset($_GET['id'])){
	$implodeStr = $_GET['id'];
}

echo "<pre>";

$db->query($objAccounts->getAcccountsByUsername($implodeStr));

$accounts = $db->fetch_all_assoc();

$loggedScreenName = '';
$result = '';
$userId = 0;

$followLogText = '';
$file = SITE_PATH.'updatelog/';

$logText = '';
$start_time = microtime(true);


foreach ($accounts as $acc){
		echo "\n ".$acc['username']." \n ";
		$auth_token = "";
		if(($acc['update_profile'] > -1 && $acc['update_profile'] < MAX_FAILURE) || ($acc['update_image'] > -1 && $acc['update_image'] < MAX_FAILURE)){
			$auth_token = $objBasicFunction->authenticate($acc);
			if($auth_token){
					$update_response = $objBasicFunction->update_profile($acc,$auth_token);
			}
		}
		$db->execute($objAccounts-> update_field_status($acc['username'],'in_process',0));
	//}
}

$debug_text = "\n ------- Update Finished ------- \n Total Time = ".((float)(microtime(true) - $start_time));
$objCommon->saveDebugContent($implodeStr,$debug_text);

$currentProcess = SITE_PATH."update_accounts.php ".$implodeStr;
include_once('footer.php');


