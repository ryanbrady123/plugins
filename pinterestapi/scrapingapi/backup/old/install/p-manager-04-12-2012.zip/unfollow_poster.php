<?php

include_once('header.php');

unset($argv[0]);// to remove the first index which will be path of cron
$thread_id = $argv[1];

if(isset($_GET['id'])){
	$thread_id = $_GET['id'];
}

echo "\n\n";
echo date('H:i:s');
echo "\n\n";

echo '<pre>';

	$start_time = date('Y-m-d H:i:s',time());
	$end_time = date('Y-m-d H:i:s',time()-($un_follow_minutes_to_process*60));
	
	$db->query($objMass_Un_Follow->get_content($thread_id,$start_time,$un_follow_minutes_to_process));
	$all_content = $db->fetch_all_assoc();
	
	$db->execute($objMass_Un_Follow->delete_content($thread_id,$start_time));
	$db->execute("OPTIMIZE TABLE un_follow_thread_".$thread_id);
	
	echo "\n\n";
	echo "Total Records = ".count($all_content);
	echo "\n\n";

	
	foreach($all_content as $c){
		$out = preg_replace('!s:(\d+):"(.*?)";!se', "'s:'.strlen('$2').':\"$2\";'", $c['content']);
		$sch = unserialize($out);
		if(DEBUG_MODE){
			echo "<pre>";
			echo "\n\n";
			print_r($sch);
		}
		
		
		if(!isset($sch['unfollow_screen_name'])){
			$result = array();
			$unfollow_date = strtotime ( '-'.$sch['days_in_past'].' day' , strtotime(date('Y-m-d'))) ;
			$unfollow_date = date ( 'Y-m-d' , $unfollow_date );
			$str_lower_username = strtolower($sch['username']);
			
			$table_fields = $objCommon->get_follow_table_name($sch['username']);
			
			// getting followers from DB		
			$db->query($objMass_Un_Follow->get_users_to_unfollow($table_fields['table_name'],1,$unfollow_date,$str_lower_username,$sch['count']));
			$listFollowers = $db->fetch_all_assoc();
			
			
			$unfollow_flag = false;
			$auth_token = "";
			if(count($listFollowers)>0){
				$allFollowersArray = array();
				if(intval($sch['all_unfollow']) == 0){
					//$auth_token = $objBasicFunction->authenticate($sch);
					//if($auth_token){	
						$stat_array = $objBasicFunction->get_counts($sch);
						print_r($stat_array);
						$allFollowersArray = $objBasicFunction->get_all_folower($sch,$stat_array['total_pages']);
					//}
				}
				
				
				foreach($listFollowers as $list_fol){
					if(intval($sch['all_unfollow']) == 1){						
						echo "\n Added in DB \n";
						$rs = array();
						$rs['unfollow_screen_name'] = $list_fol['follow_name'];
						$rs['record_id'] = $list_fol['id'];
						$rs['range_table'] = $table_fields['table_name'];
						$result[] = $rs;					
					}
					else{
						$rs = array();
						if(count($allFollowersArray)<=0){
							$stat_array = $objBasicFunction->get_counts($sch);
							$stat_array = $objBasicFunction->get_all_folower($sch,$stat_array['total_pages']);
							if($stat_array['followers_count']>0){
								$flagFollower = false;
							}
						}
						else{					
							$flagFollower = $objCommon->userExists($list_fol['follow_name'],$allFollowersArray,$sch['username']);
						}
						
						if(!$flagFollower){
							echo "\n Added in DB  with Flag\n";
							$rs['unfollow_screen_name'] = $list_fol['follow_name'];
							$rs['record_id'] = $list_fol['id'];
							$rs['range_table'] = $table_fields['table_name'];
							$result[] = $rs;
						}
						else{
							echo "\n This is mutual =".$list_fol['follow_name']." \n";
						}
					}
				}
				
				unset($allFollowersArray);
				
				if(count($result)>0){
					$insert_sql = "INSERT INTO un_follow_thread_".$thread_id." (content,publish_date,schedule_id) VALUES ";		
					foreach($result as $r_u){
						$r_u['username'] = $sch['username'];
						$r_u['password'] = $sch['password'];
						$r_u['email'] = $sch['email'];
						$r_u['proxy'] = $sch['proxy'];
						$r_u['all_unfollow'] = $sch['all_unfollow'];
						$time_random = rand(time(),(intval(strtotime($c['publish_date'])+($sch['period']*60))));
						$date_time = date('Y-m-d H:i:s',$time_random);
						$insert_sql .= "('".serialize($r_u)."','".$date_time."',".$c['schedule_id']."),";
						//$re_tweet_response = postTweetAndRewteet($r_u['username'],$r_u['password'],$r_u['proxy'],null,$tweet_id);
					}
					$insert_sql = substr($insert_sql, 0, -1)."; ";
					$db->execute($insert_sql);
				}
			
			}// if(count($listFollowers)>0)
		}
		else{
			$auth_token = $objBasicFunction->authenticate($sch);
			if($auth_token){
						
						$unfollowResult = $objBasicFunction->un_follow_single($sch,$sch['unfollow_screen_name'],$auth_token);
						if($unfollowResult){
							echo "\n Table = ".$sch['range_table'];
							echo "\n Username = ".$sch['username'];
							echo "\n User un-followed = ".$sch['unfollow_screen_name'];
							echo "\n";
							if(!empty($sch['record_id'])){
								$unfollowList[$sch['range_table']][] = $sch['record_id'];
							}
							else{
								$table_fields = $objCommon->get_follow_table_name($sch['username']);
								echo $u_sql = "UPDATE follow_table_".$table_fields['table_name']." SET status = 0, date = NOW() WHERE username  = '".$user_username."' AND follow_name = '".$sch['unfollow_screen_name']."' ";
								echo "\n";
								//$insert_sql = substr($th, 0, -1)."; ";
								$result = $db->execute($u_sql);
							}
						}
						
						if(count($unfollowList)){
							foreach($unfollowList as $key=>$u_list){
								$update_sql = "UPDATE follow_table_".$key." SET status = 0, date = NOW() WHERE id IN(".implode(",",$u_list).") ";
								echo "\n";
								//$insert_sql = substr($th, 0, -1)."; ";
								$result = $db->execute($update_sql);
							}
						}
			}
		}
		

	}
	

$currentProcess = "";

//$currentProcess = SITE_PATH."follow_poster_db_new.php ".$thread_id;

echo "\n\n\n";
echo " End Time ";
echo "\n\n\n";
echo date('H:i:s');
echo "\n\n\n";

include_once('footer.php');


