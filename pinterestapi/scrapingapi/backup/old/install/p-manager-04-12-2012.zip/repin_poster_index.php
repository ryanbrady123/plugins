<?php
	include_once('header.php');
	for($i=1;$i<=$repin_poster_threads;$i++){
		$threadCount = shell_exec("/bin/ps aux | /bin/grep '".SITE_PATH."repin_poster.php ".$i."' -c");
		echo "\n Thread = ".$threadCount ."\n";
		if($threadCount<=2){
			echo "/usr/bin/nohup  /usr/bin/php ".SITE_PATH."repin_poster.php ".$i."& ";
			echo "\n\n";
			shell_exec("/usr/bin/nohup  /usr/bin/php ".SITE_PATH."repin_poster.php ".$i."  > /dev/null & echo $!");
		}
	}
	$db->close();
