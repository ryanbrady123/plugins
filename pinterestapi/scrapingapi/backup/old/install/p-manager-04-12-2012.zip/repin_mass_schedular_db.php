<?php

include_once('header.php');

//define('POSTER_THREADS',$poster_threads);
define('REPIN_POSTER_THREADS',$repin_poster_threads);
define('PINTEREST_URL',"http://pinterest.com/");


unset($argv[0]);// to remove the first index which will be path of cron
$implode_str = $argv[1];

if(isset($_GET['id'])){
	$implode_str = $_GET['id'];
}
echo "\n\n";
echo date('H:i:s');
echo "\n\n";

echo '<pre>';


if(!file_exists(SITE_PATH.$scheduled_templates_folder_name)){
	mkdir(SITE_PATH.$scheduled_templates_folder_name,0777);
}
$db->query($objRepin_mass->getRecordsById($implode_str));
$schedules = $db->fetch_all_assoc();


// templates names
$description_template = 'description_template';
$url_template = 'url_template';
$picture_url_template = 'picture_url_template';


$thread_number = 1;
$array_thread = array();


$complete_array = array();
$count_files = 0;
foreach($schedules as $sch){
	$accounts_all = array();
	//echo $objAccounts->getAccountByNotesForMass($sch['notes']);
	$db->query($objAccounts->getAccountByNotesForMass($sch['notes']));
	$accounts = $db->fetch_all_assoc();
	echo $proxy = $accounts[0]['proxy'];
	
	
	$keywords_list = explode(",",$sch['mass_keywords']);
	$keyword = $keywords_list[array_rand($keywords_list,1)];
	$keyword = str_replace(" ","+",$keyword);
	
	$params_list = explode(",",$sch['fs_params']);
	$fs_param = $keyword = $params_list[array_rand($params_list,1)];
	
	switch($sch['type']){
		case 'user-pin':
			$url = PINTEREST_URL.$fs_param."/pins/";
			$res_html = $objCommon->get_curl_results($url, null, false,"",$proxy,null);
			$pins_array = $objBasicFunction->parse_single_user_pin($res_html,$sch['count']);
			$debug_text = "\n ------- ------------------------- ------- \n";
			$debug_text .= "\n ID = ".$sch['id'];
			$debug_text .= "\n Type= ".$sch['type'];
			$debug_text .= "\n Proxy = ".$proxy;
			$debug_text .= "\n URL = ".$url;
			$debug_text .= "\n HTML Result = ".$res_html;
			$debug_text .= "\n Pins = ".serialize($pins_array);
			$objCommon->saveDebugContent("repin_".$sch['id'],$debug_text);
			unset($debug_text);
			print_r($pins_array);
			break;		
		case 'user-board':
			$url = PINTEREST_URL.$fs_param;
			$res_html = $objCommon->get_curl_results($url, null, false,"",$proxy,null);
			$pins_array = $objBasicFunction->parse_single_user_pin($res_html,$sch['count']);
			$debug_text = "\n ------- ------------------------- ------- \n";
			$debug_text .= "\n ID = ".$sch['id'];
			$debug_text .= "\n Type= ".$sch['type'];
			$debug_text .= "\n Proxy = ".$proxy;
			$debug_text .= "\n URL = ".$url;
			$debug_text .= "\n HTML Result = ".$res_html;
			$debug_text .= "\n Pins = ".serialize($pins_array);
			$objCommon->saveDebugContent("repin_".$sch['id'],$debug_text);
			unset($debug_text);
			print_r($pins_array);
			break;		
		case 'search':
			echo $url = PINTEREST_URL."search/?q=".$keyword;
			$res_html = $objCommon->get_curl_results($url, null, false,"",$proxy,null);
			$pins_array = $objBasicFunction->parse_single_user_pin($res_html,$sch['count']);
			$debug_text = "\n ------- ------------------------- ------- \n";
			$debug_text .= "\n ID = ".$sch['id'];
			$debug_text .= "\n Type= ".$sch['type'];
			$debug_text .= "\n Proxy = ".$proxy;
			$debug_text .= "\n URL = ".$url;
			$debug_text .= "\n HTML Result = ".$res_html;
			$debug_text .= "\n Pins = ".serialize($pins_array);
			$objCommon->saveDebugContent("repin_".$sch['id'],$debug_text);
			unset($debug_text);
			print_r($pins_array);
			break;		
		case 'site':
			$url = PINTEREST_URL."source/".$fs_param;
			$res_html = $objCommon->get_curl_results($url, null, false,"",$proxy,null);
			$pins_array = $objBasicFunction->parse_single_user_pin($res_html,$sch['count']);
			$debug_text = "\n ------- ------------------------- ------- \n";
			$debug_text .= "\n ID = ".$sch['id'];
			$debug_text .= "\n Type= ".$sch['type'];
			$debug_text .= "\n Proxy = ".$proxy;
			$debug_text .= "\n URL = ".$url;
			$debug_text .= "\n HTML Result = ".$res_html;
			$debug_text .= "\n Pins = ".serialize($pins_array);
			$objCommon->saveDebugContent("repin_".$sch['id'],$debug_text);
			unset($debug_text);
			print_r($pins_array);
			break;
		default:
			break;
	}
	foreach($pins_array as $p){
		shuffle($accounts);
		$iterations = ceil($sch['rt_count']/ count($accounts));
		
		if($sch['rt_count']<count($accounts)){
			$acounts_chunks = array_chunk($accounts,$sch['rt_count']);
			$accounts_all = $acounts_chunks[0];
		}
		else{
			$accounts_all = array_fill(0,$iterations,$accounts);
		}
		foreach($accounts_all as $a_c){
			if(intval($thread_number) > REPIN_POSTER_THREADS){
				$thread_number = 1;
			}
			$a_c['pin'] = $p;
			$all_boards = explode("|??|",$sch['boards']);
			$a_c['board'] = $all_boards[array_rand($all_boards)];
			$array_thread[$thread_number][] = "('".serialize($a_c)."' , DATE_ADD(NOW() , INTERVAL ".rand(1,$sch['rt_period'])." MINUTE),".$sch['id'].")";
			$thread_number++;
		}
	}
	
	$db->execute("UPDATE repin_mass_scheduler SET next_run = DATE_ADD(NOW() , INTERVAL ".$sch['period']." MINUTE) , status = 0 WHERE id = ".$sch['id']);
	
	
	
}

/// Execute Queries
foreach($array_thread as $key=>$th){
	$insert_sql = "";
	$db->execute($objRepin_mass->create_table($key));
	$insert_sql = "INSERT INTO repin_thread_".$key." (content,publish_date,schedule_id) VALUES ".implode(",",$th);
	
	//$insert_sql = substr($th, 0, -1)."; ";
	$result = $db->execute($insert_sql);	
}

$currentProcess = SITE_PATH."mass_schedular_db.php ".$implode_str;

$end_time = microtime();

echo "\n\n\n";
echo " End Time ";
echo "\n\n\n";
echo date('H:i:s');
echo "\n\n\n";

include_once('footer.php');




