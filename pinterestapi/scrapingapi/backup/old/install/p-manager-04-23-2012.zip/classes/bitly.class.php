<?php

class Bitly extends Common{

    private $bitlyURL;

    public function Bitly() {
        //$this->bitlyURL = 'http://bit.ly/';
		$this->bitlyURL = 'http://bit.ly/m/';
		
    }
		/* returns the shortened url */
	function get_bitly_short_url($url,$login,$appkey,$format='txt',$proxy ='') {
		$connectURL = 'http://api.bit.ly/v3/shorten?login='.$login.'&apiKey='.$appkey.'&uri='.urlencode($url).'&format='.$format;
		return json_decode($this->curl_get_exec($connectURL,$proxy),true);
	}
	
	/* returns expanded url */
	function get_bitly_long_url($url,$login,$appkey,$format='txt',$proxy = '') {
		$connectURL = 'http://api.bit.ly/v3/expand?login='.$login.'&apiKey='.$appkey.'&shortUrl='.urlencode($url).'&format='.$format;
		return json_decode($this->curl_get_exec($connectURL,$proxy),true);
	}
	
	/* returns a result form url */
	function curl_get_exec($url,$proxy = '') {
		$ch = curl_init();
		$timeout = 5;
		curl_setopt($ch,CURLOPT_URL,$url);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
		curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,$timeout);
		curl_setopt($ch,CURLOPT_TIMEOUT,$timeout);
		if ($proxy){
            curl_setopt($ch, CURLOPT_PROXY, $proxy);
        }
		$data = curl_exec($ch);
		if($data == false){
			curl_error($ch);
			echo "\n Bitly Curl error: " . curl_error($ch)." for url = ".$url."\n";	
		}
		curl_close($ch);
		return $data;
	}
	
	
	
	
	
	
	public function makeShortUrl($long_url,$proxy){
		
		return $result;
	}
	public function getIndexPage(){
		$url = 'http://bit.ly/m/rd?m=1';
		parent::setCookieName('bitly'.time());
		$result = $this->get_curl_exec($url,null,true,null);
       // $result = parent::get_curl_results($url,null,true,'',null,0,'','','','BlackBerry9700/5.0.0.351 Profile/MIDP-2.1 Configuration/CLDC-1.1 VendorID/123');
        return $result;
	}
	
	public function get_xsrf($html) {
        $_xsrf = '';
        preg_match('/\<input type="hidden" name="_xsrf" value="(.*?)"\/\>/si', $html, $match);
        if (isset($match[1])) {
            $_xsrf = $match[1];
        }
        return $_xsrf;
    }
	public function getShortenURL($html){
        $_xsrf = '';
		preg_match('/\<a class="shortened" href="(.*?)"\>/si', $html, $match);
        //preg_match('/\<input type="hidden" name="_xsrf" value="(.*?)"\/\>/si', $html, $match);
		print_r($match);
		if (isset($match[1])) {
            $_xsrf = $match[1];
        }
        return $_xsrf;
    }
	
}

?>