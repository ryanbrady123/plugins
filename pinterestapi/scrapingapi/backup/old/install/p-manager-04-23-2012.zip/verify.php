<?php

include_once('header.php');

unset($argv[0]);// to remove the first index which will be path of cron
$implodeStr = $argv[1];

if(isset($_GET['id'])){
	$implodeStr = $_GET['id'];
}

echo "<pre>";

$db->query($objAccounts->getAcccountsByUsername($implodeStr));

$accounts = $db->fetch_all_assoc();

$loggedScreenName = '';
$result = '';
$userId = 0;

$followLogText = '';
$file = SITE_PATH.'updatelog/';

$logText = '';
$start_time = microtime(true);


foreach ($accounts as $acc){
		echo "\n ".$acc['username']." \n ";
		$url = "http://pinterest.com/".$acc['username']."/";
		
		$header_array[] = 'Host: pinterest.com';
		$header_array[] = 'User-Agent: Mozilla/5.0 (Windows NT 6.1; rv:8.0) Gecko/20100101 Firefox/8.0';
		$header_array[] = 'Connection: keep-alive';
		$header_array[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';
		//$header_array[] = 'Referer: https://twitter.com/';
		//$proxy = parent::getProxy();
		
		$result = $objCommon->get_curl_results($url, null, FALSE,$acc['username'],$acc['proxy'],$header_array);
		if(!empty($result)){
			if(strpos($result,"The page you're looking for could not be found.") !== false){
				if(intval($acc['created']) == 200){
					$db->execute("UPDATE accounts SET verified = 1, suspended = -1  WHERE username = '".$acc['username']."' ");
				}
				else{
					$db->execute("UPDATE accounts SET created = 0 , verified = 1, login_active = 0 , send_request = 0 WHERE username = '".$acc['username']."' ");
				}
				
			}
			else{
				$db->execute("UPDATE accounts SET verified = 1,created = 200 , login_active = 0 WHERE username = '".$acc['username']."' ");
			}
		}
		$db->execute($objAccounts-> update_field_status($acc['username'],'in_process',0));
	//}
}

$debug_text = "\n ------- Update Finished ------- \n Total Time = ".((float)(microtime(true) - $start_time));
$objCommon->saveDebugContent($implodeStr,$debug_text);

$currentProcess = SITE_PATH."update_accounts.php ".$implodeStr;
include_once('footer.php');


