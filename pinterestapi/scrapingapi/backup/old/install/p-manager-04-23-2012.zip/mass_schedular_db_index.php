<?php

	include_once('header.php');
	$threadCount = shell_exec("/bin/ps aux | /bin/grep '".SITE_PATH."mass_schedular_db.php' -c");
	//$threadCount = shell_exec("/bin/ps aux | /bin/grep '".SITE_PATH."mass_schedular.php' -c");
	//echo "\n Thread = ".$threadCount ."\n";
	if($threadCount<=2){
		$availableThread = $mass_scheduler_threads;
	}
	else{
		$availableThread = $mass_scheduler_threads-($threadCount-1);
	}

	//echo "\navailableThread = ".$availableThread;
	//echo "\n";
	
	$limit = $availableThread*$mass_scheduler_tasks;
	echo $objMass_Schedular->getRecordsId($limit);
	$db->query($objMass_Schedular->getRecordsId($limit));
	$schedules = $db->fetch_all_assoc();
	$schedules_ids = array();
	if(count($schedules)>0){
		foreach($schedules as $sc){
			$schedules_ids[] = $sc['id'];
		}
		
		$all_ids = implode(",",$schedules_ids);
		
		$objMass_Schedular->setId($all_ids);
		$objMass_Schedular->setStatus(time());
		$db->execute($objMass_Schedular->updateStatusByIds());
		//echo "\n schedules count = ".count($schedules);
		//echo "\n";
		$current_thread_count = ceil(count($schedules)/$availableThread);
		//echo "\n";
		$thread_chunks = array_chunk($schedules_ids,$current_thread_count);
		
		foreach($thread_chunks as $chunks){
			$threads = implode(",",$chunks);
			echo "/usr/bin/nohup  /usr/bin/php ".SITE_PATH."mass_schedular_db.php ".$threads;
			echo "\n\n";
			shell_exec("/usr/bin/nohup  /usr/bin/php ".SITE_PATH."mass_schedular_db.php ".$threads."  > /dev/null & echo $!");
		}
	}
$db->close();
