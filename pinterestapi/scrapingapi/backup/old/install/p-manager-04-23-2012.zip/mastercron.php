<?php

include_once('header.php');


$crons = array(	'create_index.php' => $create_index_php,
				'confirm_index.php' => $confirm_index_php,
				'follow_mass_scheduler_index.php' => $follow_mass_scheduler_index_php,
				'follow_poster_index.php' => $follow_poster_index_php,
				'mass_schedular_db_index.php' => $mass_schedular_db_index_php,
				'poster_index.php' => $poster_index_php,
				'send_request_index.php' => $send_request_index_php,
				'unfollow_mass_scheduler_index.php' => $unfollow_mass_scheduler_index_php,
				'unfollow_poster_index.php' => $unfollow_poster_index_php,
				'invitation_accounts.php' => $invitation_accounts_php,
				'repin_mass_schedular_db_index.php' => $repin_mass_schedular_db_index_php,
				'repin_poster_index.php' => $repin_poster_index_php,
				'download_images_index.php' => $download_images_index_php,
				'update_index.php' => $update_index_php,
				'verify_index.php' => $verify_index_php
				
				);
foreach($crons as $key=>$cron){
	if($cron == SERVER_ID){
		/*if($key == 'unfollow_mass_scheduler_db_index.php'){
			$file_name = SITE_PATH."unfollow_mass_scheduler_time.txt";
			$file_time = "";
			if(file_exists($file_name)){
				echo $file_time = file_get_contents($file_name);
				if($file_time<time()){
					shell_exec("/usr/bin/nohup  /usr/bin/php ".SITE_PATH.$key."  > /dev/null & echo $!");
				}
			}
			else{
				$time = time()+($unfollow_mass_scheduler_timer*60);
				file_put_contents($file_name,$time);
				shell_exec("/usr/bin/nohup  /usr/bin/php ".SITE_PATH.$key."  > /dev/null & echo $!");
			}
			continue;
		}*/
		echo $key." = ".$cron."<br>\n";
		echo "\n";
		echo "/usr/bin/nohup  /usr/bin/php ".SITE_PATH.$key."  > /dev/null \n<br>";
		shell_exec("/usr/bin/nohup  /usr/bin/php ".SITE_PATH.$key."  > /dev/null & echo $!");
	}
}



