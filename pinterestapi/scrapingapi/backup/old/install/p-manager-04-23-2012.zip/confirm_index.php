<?php

include_once('header.php');

sleep($confirm_accounts_delay);

$threadCount = shell_exec("/bin/ps aux | /bin/grep '".SITE_PATH."confirm_accounts.php' -c");

echo $threadCount ."\n";

if($threadCount<=2){
	$availableThread = $max_threads_confirm;
}
else{
	$availableThread = $max_threads_confirm-($threadCount-1);
}



	if($availableThread>0 && $availableThread<=$max_threads_confirm){
		$db->query($objAccounts->listAccountstoBeUpdateed($availableThread,$max_failure,time()));
		$accounts = $db->fetch_all_assoc();
		foreach($accounts as $acc){
			$curentThreadCount = shell_exec("/bin/ps aux | /bin/grep '/usr/bin/php ".SITE_PATH."confirm_accounts.php ".$acc['username']."' -c");
			if($curentThreadCount<=2){
				$objAccounts->setUsername($acc['username']);
				$objAccounts->setLastRun(time());
				$sql = $objAccounts->updateLastRun();
				$db->execute($sql);
				echo "/usr/bin/nohup  /usr/bin/php ".SITE_PATH."confirm_accounts.php ".$acc['username']." &\n";
				shell_exec("/usr/bin/nohup  /usr/bin/php ".SITE_PATH."confirm_accounts.php ".$acc['username']." > /dev/null & echo $!");
			}
		}
		
	}
$db->close();


