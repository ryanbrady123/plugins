<?php

	$proxy = $_GET['ipaddress'];
	if(empty($proxy)){
		unset($argv[0]);// to remove the first index which will be path of cron
		$proxy = $argv[1];
	}
	
	if(!empty($proxy)){
	
		echo '<br>';
		echo 'URL = '.$url = "http://pinterest.com/";
		echo '<br>';
		
		$agent = 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.2.13) Gecko/20101203 AskTbUT2V5/3.9.1.14019 Firefox/3.6.13';
	
		$cookie_file_path = 'mycookie.txt';	
		//$cookie_file_path = "cookie.txt";
		$fp = fopen($cookie_file_path, "wb");
		fclose($fp);
		
		$ch = curl_init(); 
		 curl_setopt($ch, CURLOPT_URL,$url);
		 curl_setopt($ch, CURLOPT_USERAGENT, $agent);
		 //curl_setopt($ch, CURLOPT_HTTPHEADER, $header_array);
		 
		 curl_setopt($ch, CURLOPT_PROXY, $proxy);
		 //curl_setopt($ch, CURLOPT_POST, 1);
		 //curl_setopt($ch, CURLOPT_POSTFIELDS, $postfields);
		 curl_setopt($ch, CURLOPT_TIMEOUT, 10);
		 curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
		 //curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie_file_path);
		 //curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie_file_path);
		
	   echo	$result = curl_exec($ch);
	//print_r(curl_getinfo($ch));
	
		if($result === false){			
			print_r(curl_error($ch));
		}
		 curl_close ($ch);
	}
