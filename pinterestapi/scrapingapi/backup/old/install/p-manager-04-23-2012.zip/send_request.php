<?php
include_once('header.php');

$allFollowersArray = array();
$allFollowingsArray = array();


unset($argv[0]);// to remove the first index which will be path of cron
$implodeStr = $argv[1];


if(isset($_GET['id'])){	
	$implodeStr = $_GET['id'];
}

$db->query($objAccounts->getAcccountsByUsername($implodeStr));
$accounts = $db->fetch_all_assoc();

$current_error_code = '';

$start_time = microtime(true);//(round($usec, 2) + (float)$sec)

foreach ($accounts as $acc){
	$debug_text = '';
	$date = date('Y-m-d H:i:s');
	if($acc['send_request'] == 100){
		//echo $objPinterest->get_request_page($acc);
		
		/*echo $result = $objPinterest->send_signup_request($acc);
		if(strpos($result,'Thanks!') !== false){
			$db->execute($objAccounts->sql_account_got_request($acc['username']));
			//$db->execute($objAccounts->update_field_status($acc['username'],'send_request',200));
		}
		elseif(empty($result)){
			$objBasicFunction->update_code_field_error($acc,'send_request',$acc['send_request'],-2);
		}*/
			
	}
	elseif($acc['send_request'] == 150){
		$db->query($objAccounts->listAccountsForInvitation($acc['request_count']));
		$request_accounts = $db->fetch_all_assoc();
		$auth_token = $objBasicFunction->authenticate($acc);
		if($auth_token){
					
				$follow_result = $objBasicFunction->send_invitation($acc,$auth_token,$request_accounts);
				/*if($follow_result){
					$table_fields = $objCommon->get_follow_table_name($sch['username']);
					echo "\n Table = ".$table_fields['table_name'];
					echo "\n Username = ".$sch['username'];
					echo "\n User to follow = ".$sch['screen_name'];
					echo "\n";
					$db_values[$table_fields['table_name']][] = "('".strtolower($sch['username'])."','".$sch['screen_name']."',1,NOW())";								
				}*/
		}
		else{
			$objBasicFunction->update_erros_codes($acc,'login_active',LOGIN_FAILED_ERROR);
		}
		
		
		
	}
	
	$db->execute($objAccounts->update_field_status($acc['username'],'in_process',0));
	
	$next_run  = time()+(60*$acc['period']);
	$next_run  = date('Y-m-d H:i:s',$next_run);
	$db->execute("UPDATE accounts SET last_run = '".$next_run."' WHERE username  = '".$acc['username']."'");
	
	$debug_text = "\n ------- Creation Finished ------- \n Total Time = ".((float)(microtime(true) - $start_time));
	$objCommon->saveDebugContent($acc['username'],$debug_text);
	
}

$currentProcess = SITE_PATH."send_request.php ".$implodeStr;

include_once('footer.php');
