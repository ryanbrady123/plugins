<?php

include_once('header.php');

sleep($create_accounts_delay);

$threadCount = shell_exec("/bin/ps aux | /bin/grep '".SITE_PATH."create_accounts.php' -c");

echo $threadCount ."\n";

if($threadCount<=2){
	$available_thread = $create_threads;
}
else{
	$available_thread = $create_threads-($threadCount-1);
}
	
	
	
	$limit = $available_thread*$create_tasks_per_thread;
	$db->query($objAccounts->listAccountsToBeCreated($limit));
	$users = $db->fetch_all_assoc();
	$user_names = array();
	if(count($users)>0){
		foreach($users as $us){
			$user_names[] = $us['username'];
		}
		$db->execute($objAccounts->updateInProcess($user_names,1));
		$current_thread_count = ceil(count($users)/$available_thread);
		$thread_chunks = array_chunk($user_names,$current_thread_count);
		echo '<pre>';
		print_r($thread_chunks);
		
		foreach($thread_chunks as $chunks){
			$threads = implode(",",$chunks);
			
			echo "/usr/bin/nohup  /usr/bin/php ".SITE_PATH."create_accounts.php ".$threads."& ";
			echo "\n\n";
			shell_exec("/usr/bin/nohup  /usr/bin/php ".SITE_PATH."create_accounts.php ".$threads."  > /dev/null & echo $!");
			//$threadCount = shell_exec("/bin/ps aux | /bin/grep '".SITE_PATH."mass_schedular_db.php' -c");
			
			
		}
	}
	

$db->close();


