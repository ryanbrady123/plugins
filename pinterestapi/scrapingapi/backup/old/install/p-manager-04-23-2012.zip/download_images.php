<?php

include_once('header.php');




unset($argv[0]);// to remove the first index which will be path of cron
$implodeStr = $argv[1];

if(isset($_GET['id'])){
	$implodeStr = $_GET['id'];
}


$db->query($objAccounts->getAcccountsByUsername($implodeStr));
echo '<pre>';
$accounts = $db->fetch_all_assoc();


$result = '';
$userId = 0;

$followLogText = '';
//$file = SITE_PATH.'updatelog/'.date('Ymd').'.txt';

$logText = '';



foreach ($accounts as $acc){
	print_r($acc);
	$start_time = microtime(true);
	$profile_image = '';
	$design_image = '';
	if($acc['update_image'] == 100){
		$profile_image = $objCommon->flickerImageResults(trim($acc['avatar_keyword']),$flicker_images_url,trim($acc['proxy']),$acc['username']);
	}else if($acc['update_image'] == 150){
		$profile_image = $objCommon->googleImageResults(trim($acc['avatar_keyword']),$google_images_url,trim($acc['proxy']),$acc['username']);
	}
	if(!empty($profile_image)){	
		$db->execute($objAccounts->updateProfileAndImage(0,$acc['username'],PICTURES_PATH.DOWNLOAD_FOLDER.$profile_image));
	}
	elseif(is_null($profile_image)){
		$db->execute($objAccounts->updateProfileAndImage(EMPTY_RESPONSE,$acc['username']));
	}
	else{
		$db->execute($objAccounts->updateProfileAndImage(EMPTY_AFTER_PROCESS,$acc['username']));
	}
	
	$db->execute($objAccounts-> update_field_status($acc['username'],'in_process',0));
	
	$debug_text = "\n ------- Donwload Images Finished ------- \n Total Time = ".((float)(microtime(true) - $start_time));
	$objCommon->saveDebugContent($acc['username'],$debug_text);
		
}


/*if(!empty($logText) && LOG_ENABLED){
	file_put_contents($file, $logText,FILE_APPEND);
}*/
//$objCommon->saveDebugContent('Download images for User : '.$implodeStr." \n Total Time : ".((float)(microtime(true) - $start_time)));
//$objCommon->saveDebugContent('-----------------------------------------------------------------------------------------------------------');

$currentProcess = SITE_PATH."download_images.php ".$implodeStr;

include_once('footer.php');


