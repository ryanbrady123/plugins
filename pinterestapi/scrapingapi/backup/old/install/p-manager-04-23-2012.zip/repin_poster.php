<?php

include_once('header.php');


	unset($argv[0]);// to remove the first index which will be path of cron
	$thread_id = $argv[1];
	
	if(isset($_GET['id'])){
		$thread_id = $_GET['id'];
	}

	echo '<pre>';

	$start_time = date('Y-m-d H:i:s',time());
	$end_time = date('Y-m-d H:i:s',time()-($poster_minutes_to_process*60));
	
	echo "Query = ".$objRepin_mass->get_content($thread_id,$start_time,$poster_minutes_to_process);
	
	$db->query($objRepin_mass->get_content($thread_id,$start_time,$poster_minutes_to_process));
	$all_content = $db->fetch_all_assoc();
	
	$db->execute($objRepin_mass->delete_content($thread_id,$start_time));
	$db->execute("OPTIMIZE TABLE repin_thread_".$thread_id);
	
	echo "\n\n";
	echo "Total Records = ".count($all_content);
	echo "\n\n";
	
		
	foreach($all_content as $c){
		$out = preg_replace('!s:(\d+):"(.*?)";!se', "'s:'.strlen('$2').':\"$2\";'", $c['content']);
		$cnt = unserialize($out);
		print_r($cnt);
		if(isset($cnt['pin']['pin_id'])){
			$pin = $cnt['pin'];
			if(!empty($cnt)){			
				$auth_token = $objBasicFunction->authenticate($cnt);
				if($auth_token){
					$pin_response = $objBasicFunction->post_repin($cnt,$pin,$auth_token,true);
					//($acc, $pin, $auth_token,$add_board = false)
				}
			}
		}
	}
	


	$currentProcess = SITE_PATH."repin_poster.php ".$thread_id;
	
	echo "\n\n\n";
	echo " End Time ";
	echo "\n\n\n";
	echo date('H:i:s');
	echo "\n\n\n";
	
	include_once('footer.php');


