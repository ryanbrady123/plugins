<?php
	include_once('header.php');
	
	echo '<pre>';
	$db->query("SELECT count(username) as count FROM accounts WHERE send_request = 0 AND created = 0 AND login_active = 0 ");
	$counter = $db->fetch_all_assoc();
	print_r($counter);
	
	$db->query("SELECT username FROM accounts WHERE send_request = 200 AND created = 200 AND login_active = 0  ORDER BY RAND() LIMIT ".$counter[0]['count']);
	$inviters = $db->fetch_all_assoc();
	
	
	$users = array();
	foreach($inviters as $inite){
		$users[] = $inite['username'];
		//$db->execute("UPDATE accounts SET send_request = 150 WHERE username = '".$inite."'");
	}
	
	$all_users = implode("','",$users);
	
	$db->execute("UPDATE accounts SET send_request = 150 , request_count = 5 WHERE username IN( '".$all_users."')");
	
	
$db->close();