<?php 
	
	require('classes/basicfunctions.php');
	$objOptions = new Options();
	$objAccounts = new Accounts();	
	$objBasicFunction = new BasicFunctions();	
	$objCommon = new Common();

	$objPinterest = new Pinterest();
	$objMass_Schedular = new Mass_Scheduler();
	$objEmailAPI = new EmailAPI();
	$objBitly = new Bitly();
	
	$obj_unique = new Unique();
	$objSimple_html_dom = new simple_html_dom();
	
	
	/*$objTwitter = new Twitter();
	$objScheduleTweets = new Scheduletweets();
	$objTweets = new Tweets();	
	$objFollow = new Follow();
	$objUnFollow = new Unfollow();
	$objLists = new Lists();
	$objMass_Follow = new Mass_Follow();
	$objMass_Un_Follow = new Mass_Unfollow();*/

	$db->connect();
	
	$db->query($objOptions->selectAll());
	$optionsArray = $db->fetch_all_assoc();
	$options = array();
	foreach($optionsArray as $opt)
	$options[$opt['name'] ] = $opt['value'];
	extract($options, EXTR_OVERWRITE );
	
	if($notices){
		error_reporting(E_ALL);
		ini_set("display_errors",1);
	}
	else{
		error_reporting(5);	
	}
	
	define('REQUEST_TIMEOUT',$request_timeout);
	define('MAX_FAILURE',$max_failure);
	define('DEBUG_MODE',$debug_mode);
	define('CHECK_EMAIL_TIME',$check_email_time);
	define('API_KEYS',$check_email_time);
	define('MAX_TEMPLATE_COMBINATIONS',$max_templates_combinations);
	
	
	
	
/*	define('LOG_ENABLED',$log_enabled);
	define('PICTURES_PATH',$picture_path);
	define('DOWNLOAD_FOLDER',$download_folder_name."/");*/
	
	//URLS //	
	define('GOOGLE_BLOG_SEACRH_URL',$googleblogsearch_url);
	define('GOOGLE_NEWS_URL',$googlenews_url);
	define('YAHOO_NEWS_URL',$yahoonews_url);
	define('ALL_OTHER_FEED_COUNT',$all_other_feed_count);	
	// Sources  
	define('SOURCES_CACHE_EXPIRY_TIME',$sources_cached_expiry_time);
	// Sources Count
	define('GOOGLE_BLOG_FEED_COUNT',$googleblog_feed_count);
	define('YAHOO_NEWS_FEED_COUNT',$yahoonews_feed_count);
	define('GOOGLE_NEWS_FEED_COUNT',$googlenews_feed_count);
	define('AMAZON_FEED_COUNT',$amazon_feed_count);
	// User Agents  
	define('USER_AGENTS',$user_agents);
	// Proxies  
	define('USER_PROXIES',$user_proxies);