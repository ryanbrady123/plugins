<?php

include_once('header.php');


	unset($argv[0]);// to remove the first index which will be path of cron
	$thread_id = $argv[1];
	
	if(isset($_GET['id'])){
		$thread_id = $_GET['id'];
	}

	echo '<pre>';

	$start_time = date('Y-m-d H:i:s',time());
	$end_time = date('Y-m-d H:i:s',time()-($poster_minutes_to_process*60));
	
	echo "Query = ".$objMass_Schedular->get_content($thread_id,$start_time,$poster_minutes_to_process);
	
	$db->query($objMass_Schedular->get_content($thread_id,$start_time,$poster_minutes_to_process));
	$all_content = $db->fetch_all_assoc();
	
	$db->execute($objMass_Schedular->delete_content($thread_id,$start_time));
	$db->execute("OPTIMIZE TABLE thread_".$thread_id);
	
	echo "\n\n";
	echo "Total Records = ".count($all_content);
	echo "\n\n";
	
	
		
	foreach($all_content as $c){
		$out = preg_replace('!s:(\d+):"(.*?)";!se', "'s:'.strlen('$2').':\"$2\";'", $c['content']);
		$cnt = unserialize($out);
		print_r($cnt);
		
		if(isset($cnt['pin_id'])){
			echo "\n Re-Pin by => ".$cnt['username'];
			echo "\n Re-Tweet content => ";
			print_r($cnt['content_to_post']);
			echo "\n";
			$cnt['content_to_post']['pin_id'] = $cnt['pin_id'];
			$re_tweet_response = postPinAndRepin($cnt,$cnt['content_to_post'],$cnt['pin_id'],true);
		}
		else{
			$params = array();	
			$url_result = null;
			$content_to_post = null;
			$template = $cnt['template'];
			
			$description_template = $cnt['template']['description_template'];
			$url_template = $cnt['template']['url_template'];
			$picture_url_template = $cnt['template']['picture_url_template'];
			$fs_title_keyword = '';
			$source_content = null;
			if($cnt['type'] != 'basic' && $cnt['type'] != 'basic_account'){
				$url = str_replace(" ","+",$cnt['params']['simple_url']);
				
				if($cnt['type'] == 'fs-title' || $cnt['type'] == 'fs-title-account'){
					
					if(isset($cnt['is_count_source']) && $cnt['is_count_source']){
						$source_content = $objCommon->get_cached_source($url);						
						$fs_title_keyword = str_replace(' ','+',$source_content['keyword']);
						$source_content = $source_content['content'];
					}
					if(is_null($source_content)){
						$url_result = $objCommon->get_curl_results($url,null,false,null,null,null,$cnt['proxy']);					
						$debug_text = "\n ------- Fast-site (Before Parsing) ------- \n";
						echo $debug_text .= "\n url = ".$url;
						$debug_text .= "\n Result = ".$url_result;
						$objCommon->saveDebugContent($cnt['username'],$debug_text);
						
						$source_content = json_decode($url_result,true);
						
						$debug_text = "\n ------- Fast-site (After Parsing) ------- \n";
						$debug_text .= "\n url = ".$url;
						$debug_text .= "\n Result= ".$url_result;
						$objCommon->saveDebugContent($cnt['username'],$debug_text);
						if(isset($cnt['is_count_source']) && $cnt['is_count_source']){
							$objCommon->store_cached_source($url,$source_content);							
						}
						$fs_title_keyword = str_replace(' ','+',$source_content['keyword']);
						$source_content = $source_content['content'];
					}
					
					
				}
				else{
					if(isset($cnt['is_count_source']) && $cnt['is_count_source']){
						$source_content = $objCommon->get_cached_source($url);
					}
					if(is_null($source_content)){
						$url = str_replace(" ","+",$cnt['params']['simple_url']);		
						if($cnt['type'] == 'amazon' || $cnt['type'] == 'amazoncount'){
							echo "\n\n";
							echo "URL = ".$url;
							echo "\n\n";
							$header_array[] = 'Host: www.amazon.com';
							$header_array[] = 'User-Agent: Mozilla/5.0 (Windows NT 6.1; rv:10.0.2) Gecko/20100101 Firefox/10.0.2';
							$header_array[] = 'Connection: keep-alive';
							$url_result = $objCommon->get_curl_results_source($url,"amazon_".$cnt['username'],'',$header_array,$cnt['proxy']);
							
							$debug_text = "\n ------- Amazon (Before Parsing) ------- \n";
							$debug_text .= "\n url = ".$url;
							$debug_text .= "\n Result= ".$url_result;
							$objCommon->saveDebugContent($cnt['username'],$debug_text);
							
							$source_content = $objCommon->amazonSearchContentFilter($url_result,5,$cnt['username']);
							
							$debug_text = "\n ------- Amazon (After Parsing) ------- \n";
							$debug_text .= "\n url = ".$url;
							$debug_text .= "\n Result= ".serialize($source_content);
							$objCommon->saveDebugContent($cnt['username'],$debug_text);
						}
						else{
							$Feeds = $objBasicFunction->get_feeds($url,$cnt['proxy'],$cnt['username'],$cnt['type'],$cnt['username'],"Rss for Poster");
							if($cnt['type'] == 'googleblogsearch' || $cnt['type'] == 'googleblogsearchcount'){
								$source_content = $objCommon->googleBlogSearchContentFilter($Feeds,5,$cnt['username']);
							}
							
							elseif($cnt['type'] == 'googlenews' || $cnt['type'] == 'googlenewscount'){						
								$source_content = $objCommon->googleNewsContentFilter($Feeds);
							}
							elseif($cnt['type'] == 'yahoonews' || $cnt['type'] == 'yahoonewscount'){
								$source_content = $objCommon->yahooNewsContentFilter($Feeds);
							}
							elseif($cnt['type'] == 'feed' || $cnt['type'] == 'delicious' || $cnt['type'] == 'surchur' || $cnt['type'] == 'feedcount' || $cnt['type'] == 'deliciouscount' || $cnt['type'] == 'surchurcount'){
								$source_content = $objCommon->feedContentFilter($Feeds);
							}
						
						}
						if(isset($cnt['is_count_source']) && $cnt['is_count_source']){
							$objCommon->store_cached_source($url,$source_content);							
						}						
					}
				}
				
				if(!isset($cnt['ended']) && isset($cnt['params']['user_count']) ){
						if($cnt['params']['user_count']>0){
							$params['simple_url'] = $url;
							$insert_sql = "INSERT INTO thread_".$thread_id." (content,publish_date,schedule_id) VALUES ";
							
							$c_title_template = $cnt['template']['description_template'];
							$c_desc_template 	= $cnt['template']['url_template'];
							$c_tags_template 	= $cnt['template']['picture_url_template'];	
							
							for($i=0;$i<$cnt['params']['user_count'];$i++){
								$c_template =$all_templates[array_rand($all_templates,1)];
								$r_u = array(	
											'username'				=>	$cnt['username'],
											'password'				=>	$cnt['password'],
											'proxy'					=>	$cnt['proxy'],
											'keyword'				=>	$cnt['keyword'],
											'is_count_source'		=>	$cnt['is_count_source'],
											'ended'					=>	1,
											'type'					=>	$cnt['type'],
											'bitly_api_login'		=>	$cnt['bitly_api_login'],
											'bitly_api_key'			=>	$cnt['bitly_api_key'],
											'lang'					=>	$cnt['lang'],
											'description_template'	=>	$c_title_template,
											'url_template'			=>	$c_desc_template,
											'picture_url_template'	=>	$c_tags_template,
											'params'				=>	$params
											);
								$time_random = rand(time(),(intval(strtotime($c['publish_date'])+($cnt['period']*60))));
								$date_time = date('Y-m-d H:i:s',$time_random);
								$insert_sql .= "('".serialize($r_u)."','".$date_time."',".$c['schedule_id']."),";
							}
							$insert_sql = substr($insert_sql, 0, -1)."; ";
							if($cnt['params']['all_templates']==20){
								echo "\n\n\n";
								//echo $insert_sql;
								echo "\n\n\n";
							}
							$db->execute($insert_sql);
						}
						continue;
				}
				
				if($c['schedule_id'] == 20){
					//echo "\n cnt = ";
					//print_r($cnt);
					//echo "\n Result = ";
					//print_r($source_content);
				}
				
				$obj_unique->buildContent($description_template,$source_content,$cnt['urls_array'],$cnt['type'],$cnt['keyword']);
				$obj_unique->buildContent($url_template,$source_content,$cnt['urls_array'],$cnt['type'],$cnt['keyword']);
				$obj_unique->buildContent($picture_url_template,$source_content,$cnt['urls_array'],$cnt['type'],$cnt['keyword']);
				/*
				echo "<br><br>description_template<br>";
				echo $description_template;
				echo "<br><br>url_template<br>";
				echo $url_template;
				echo "<br><br>picture_url_template<br>";
				echo $picture_url_template;
				
				exit;
				*/
				$findArray = array('$domain$','$keyword$');
				$replaceArray = array($cnt['fast_site_url'],str_replace("+"," ",$cnt['keyword']));
				// for domain // for keyword
				$description_template = str_replace($findArray ,$replaceArray ,$description_template);
				// for domain // for keyword
				$url_template = str_replace($findArray ,$replaceArray ,$url_template);
				// for domain // for keyword
				$picture_url_template = str_replace($findArray ,$replaceArray ,$picture_url_template);
				// for title
				$objCommon->replaceTitle($template,$source_content);
				// for description
				$objCommon->replaceDescription($template,$source_content);
				
				if($cnt['type'] == 'amazon' || $cnt['type'] == 'amazoncount'){
					// for price
					$objCommon->replacePrice($description_template,$source_content);
					// for reviews
					$objCommon->replaceReviews($description_template,$source_content);
					// for rating
					$objCommon->replaceRating($description_template,$source_content);
					// for image
					$objCommon->replaceImage($description_template,$source_content);
				}
				// for domain
				$template = str_replace('$domain$',$cnt['params']['fast_site_url'],$template);							
				// for keyword
				$template = str_replace('$keyword$',str_replace(' ','+',$fs_title_keyword),$template);
				// replace url for sources
				if($cnt['type']!='fs-title' || $cnt['type']!='fs-title-account'){
					$objCommon->replaceURL($description_template,$source_content,$cnt['type'],$cnt['urls_array']);
					$objCommon->replaceURL($url_template,$source_content,$cnt['type'],$cnt['urls_array']);
					$objCommon->replaceURL($picture_url_template,$source_content,$cnt['type'],$cnt['urls_array']);
				}
				// replace tags
				$objCommon->replaceTags($description_template,$source_content);
			}
			// replace url for sources
			if($cnt['type']!='fs-title'){					
				$objCommon->replaceURL($description_template,$source_content,$cnt['type'],null);
				$objCommon->replaceURL($url_template,$source_content,$cnt['type'],null);
				$objCommon->replaceURL($picture_url_template,$source_content,$cnt['type'],null);
			}
			// for bitly
			$current_url = $objCommon->replaceBitlyURL($description_template,null,$cnt['proxy'],$cnt);	
			$current_url = $objCommon->replaceBitlyURL($url_template,null,$cnt['proxy'],$cnt);	
			$current_url = $objCommon->replaceBitlyURL($picture_url_template,null,$cnt['proxy'],$cnt);
			// for urls to get contant
			$objCommon->replace_content($description_template,$cnt['proxy']);
			// for translation
			$objCommon->replaceTranslation($description_template,$cnt['proxy']);
			/*echo '<pre><br>title_template <br>';
			echo $title_template ;
			echo '<pre><br>desc_template <br>';
			echo $desc_template ;
			echo '<pre><br>tags_template <br>';
			echo $tags_template;
			echo '<pre><br>url_template <br>';
			echo $url_template;*/
						
			/***** for trim function ***/
			// for description_template
			$objCommon->replaceTrim($description_template,$current_url);
			$objCommon->replaceEmptyTrim($description_template);
			$objCommon->replaceEmptyBilty($description_template);
			$objCommon->replaceEmptyTranslation($description_template);
			$objCommon->replaceEmptyEndPoint($description_template);
			// for url_template
			$objCommon->replaceTrim($url_template,$current_url);
			$objCommon->replaceEmptyTrim($url_template);
			$objCommon->replaceEmptyBilty($url_template);
			$objCommon->replaceEmptyTranslation($url_template);
			$objCommon->replaceEmptyEndPoint($url_template);
			// for picture_url_template
			$objCommon->replaceTrim($picture_url_template,$current_url);
			$objCommon->replaceEmptyTrim($picture_url_template);
			$objCommon->replaceEmptyBilty($picture_url_template);
			$objCommon->replaceEmptyTranslation($picture_url_template);
			$objCommon->replaceEmptyEndPoint($picture_url_template);
			
			
			$content_to_post['description'] = trim($description_template);
			$content_to_post['url'] = trim($url_template);
			$content_to_post['picture_url'] = trim($picture_url_template);
			
			$content_to_post['board'] = trim($cnt['board']);		
			echo "\n\n";
			
			if(!is_null($content_to_post) && !empty($content_to_post)){
				$pin_response = postPinAndRepin($cnt,$content_to_post,0);
				$pin_id = 0;
				if(isset($pin_response['url'])){
					$pin_id = str_replace(array("pin","/"),"",$pin_response['url']);
				}
				if(isset($cnt['rt_users']) && count($cnt['rt_users'])>0 && $pin_id > 0){
					$insert_sql = "INSERT INTO thread_".$thread_id." (content,publish_date,schedule_id) VALUES ";		
					foreach($cnt['rt_users'] as $r_u){
						$r_u['pin_id'] = $pin_id;
						$r_u['pin_user'] = $cnt['username'];
						$r_u['board'] = $content_to_post['board'];
						$r_u['content_to_post'] = $content_to_post;
						$r_u['user_boards'] = $cnt['user_boards'];
						$time_random = rand(time(),(time()+intval($cnt['rt_period']*60)));
						$date_time = date('Y-m-d H:i:s',$time_random);
						$insert_sql .= "('".serialize($r_u)."','".$date_time."',".$c['schedule_id']."),";
						//$re_tweet_response = postPinAndRepin($r_u['username'],$r_u['password'],$r_u['proxy'],null,$tweet_id);
					}
					$insert_sql = substr($insert_sql, 0, -1)."; ";
					$db->execute($insert_sql);
				}
			}			
		}
	}
	
	function postPinAndRepin($user,$pin = '',$pin_id = 0){
		$tweetResponse = array();	
		$flag = 0;		
		global $objCommon, $objBitly, $objScheduleTweets, $objTweets, $objOptions, $objAccounts, $objTwitter, $objBasicFunction, $db;		
		$loggedScreenName = '';
		$cookie_name = $user;
		
		//echo $objAccounts->get_active_accounts($user);
		//$db->query($objAccounts->get_active_accounts($user));
		//$user = $db->fetch_all_assoc();
		if(!empty($user)){			
			$auth_token = $objBasicFunction->authenticate($user);
			if($auth_token){
				if($pin_id){
					$pin_response = $objBasicFunction->post_pin($user,$pin,$auth_token,true,true);
				}
				else{
					$pin_response = $objBasicFunction->post_pin($user,$pin,$auth_token,true);
				}
				if($pin_response){
					return $pin_response;
				}else{
					return false;
				}
			}
		}
		
		
		/*$twitterLoginResult = $objTwitter->getLoginPage($currentProxy,$cookie_name);		
		$loggedScreenName = $objBasicFunction->authenticate($user,$pass,$twitterLoginResult,$cookie_name);		
		if(!empty($loggedScreenName)){
			$objAccounts->setUsername($user);
			$accounts_details = $objTwitter->getAccountDetail($user);
			$userId = intval($accounts_details['requestCacheSeedData'][0]['json']['id_str']);
			if($userId){
				$suspended = $objBasicFunction->is_suspended($accounts_details,$user);
				if(!$suspended){
					echo "\n Auth Token = ".$accounts_details['postAuthenticityToken']."\n";
					$objTwitter->setGolbalAuthToken($accounts_details['postAuthenticityToken']);
					if($tweet_id == 0){	
						$tweetResponse = $objTwitter->doTweet($loggedScreenName,$content);
						echo "\n Tweet REsponse = ".serialize($tweetResponse)."\n";
					}
					else{
						$tweetResponse = $objTwitter->doReTweet($loggedScreenName,$tweet_id);
					}
				}
			}
		}*/

		return false;
	
	}
	
	
// For Simple Poster

/*unset($argv[0]);// to remove the first index which will be path of cron
$all_ids = $argv[1];

if(isset($_GET['id'])){
	$all_ids = $_GET['id'];
}

echo "<pre>";
echo "\n\n";
echo date('H:i:s');
echo "\n\n";


$start_time = date('Y-m-d H:i:s',time());
if(!empty($all_ids)){
	$db->query("SELECT * FROM schedule_pins WHERE id IN(".$all_ids.")");
	$all_pins = $db->fetch_all_assoc();
	foreach($all_pins as $pin){
		echo $objAccounts->get_active_accounts($pin['username']);
		$db->query($objAccounts->get_active_accounts($pin['username']));
		$user = $db->fetch_all_assoc();
		if(!empty($user[0])){			
			$auth_token = $objBasicFunction->authenticate($user[0]);
			if($auth_token){
				if($objBasicFunction->post_pin($user[0],$pin,$auth_token)){
					echo "\nPin Posted\n";
					echo "\nPin id =  ".$pin['id']."\n";
				}
			}
		}
	}
}
*/

	

$currentProcess = SITE_PATH."poster_db.php ".$thread_id;

echo "\n\n\n";
echo " End Time ";
echo "\n\n\n";
echo date('H:i:s');
echo "\n\n\n";

include_once('footer.php');


