<?php
class Unique extends Common{

	
	public $keyword;
	public $all_sources;
	
	
	public function Unique(){
		$this->keyword = "";
		$this->all_sources = array();
	}
    

	public function buildContent(&$template,$source_content,$urls_array,$source_type,$keyword = ''){
		echo $this->keyword = $keyword;
		if($source_type == 'multi'){
			$current_sources =array();
			foreach($source_content as $url_token => $src){
				if(strpos(strtolower($url_token),strtolower(GOOGLE_BLOG_SEACRH_URL)) !== false){
					$current_sources['googleblogsearch'] = $src;
				}
				elseif(strpos(strtolower($url_token),strtolower(GOOGLE_NEWS_URL)) !== false){
					$current_sources['googlenews'] = $src;
				}
				elseif(strpos(strtolower($url_token),strtolower(YAHOO_NEWS_URL)) !== false){
					$current_sources['yahoonews'] = $src;
				}
				elseif(strpos(strtolower($url_token),strtolower(YOUTUBE_URL)) !== false){
					$current_sources['youtube'] = $src;
				}
				elseif(strpos(strtolower($url_token),strtolower(FLICKER_URL)) !== false){
					$current_sources['flickr'] = $src;
				}
				elseif(strpos(strtolower($url_token),strtolower(DELICIOUS_URL)) !== false){
					$current_sources['delicious'] = $src;
				}
				else{
					$current_sources['feed'] = $src;
				}
			}
			$this->all_sources = $current_sources;
			//echo '<pre><br>titleResult <br>';
			//print_r($this->all_sources);
			unset($current_sources);
		}
		else{
			
			$this->all_sources[$source_type] = $source_content;
		}
		
		unset($source_content);
	
		if(!empty($template)){
			//echo '<pre>';
			//echo '<br><br> File Content<br><br>';
			//$template	= file_get_contents($template_file);
			
			/*$madapi	= new madapi();
			
			$madapi->fromString($template);
			$array = $madapi->produce(1);
			//echo '<pre>';
			//print_r($array);
			echo $template = $array[0];
			exit;*/
			
			//print_r($template);
			$this->replace_dates($template);
				//$this->replace_related_keywords($template);
				//echo '<br><br> Related Keywords<br><br>';
				//print_r($template);			
				//$this->replace_words($template);
				//echo '<br><br> Replace Words<br><br>';
			//print_r($template);			
				//$this->replace_blog_titles($template);
				//echo '<br><br>Blog Titles<br><br>';
			//print_r($template);			
			$this->replace_subject_keyword($template,$this->keyword);
				//echo '<br><br> Subject Keywords<br><br>';
				//print_r($template);
			
			$this->replace_conditional_statements($template);
			
			$this->remove_empty_words($template);
			//$this->remove_empty_sources_words($template);
			$this->replace_nested_if_sources($template);
			$this->replace_all_empty_sources_words($template);
			$this->replace_junk_charcters($template);
			
			
			
			/*$madapi	= new madapi();
			
			$madapi->fromString($template);
			$madapi_array = $madapi->produce(1);
			$template = $madapi_array[0];
			$this->replaceInnerWords($template);
			$return_array[0] = $template;*/
									
			return $template;

		}
		else return false;
	}
	
	public function replace_dates(&$template){		
		$pattern = '/\$date\$\!/si';
		preg_match_all($pattern, $template, $titles_to_replace);
		if(isset($titles_to_replace[0]) && count($titles_to_replace[0])>0){
			foreach($titles_to_replace[0] as $key => $titles){
				$today = date("F j, Y");
				$template = str_replace($titles,$today,$template);
			}
		}
		$titles_to_replace = array();
		$pattern = '/\$num_date\$\!/si';
		preg_match_all($pattern, $template, $titles_to_replace);
		if(isset($titles_to_replace[0]) && count($titles_to_replace[0])>0){
			foreach($titles_to_replace[0] as $key => $titles){
				$today = date("m-d-Y");
				$template = str_replace($titles,$today,$template);
			}
		}
	}
	
	public function replace_related_keywords(&$template){
        
        $patern    	= '/\$related-term([0-9]+)\$\!/';
        //$altered   = preg_replace_callback($patern, "UniqueContentBuilder::replace_related_keywords", $template);

		$related_keyword_replace	= array();
		preg_match_all($patern, $template, $related_keyword_replace);
		if(isset($related_keyword_replace[0]) && count($related_keyword_replace[0])>0){
			$related_keywords	= common::get_related_searches($this->Keyword,24,true);		
			foreach($related_keyword_replace[0] as $counter => $related_term_rep_str){
				if(isset($related_keywords[$counter])){
					$replacement_keyword	= parent::clean_text($related_keywords[$counter]);
					$this->relatedTermsArray[] = $replacement_keyword;
					$template	= str_replace($related_term_rep_str, $replacement_keyword, $template);
				}
				else{
					//replace with nothing
					$template	= str_replace($related_term_rep_str, '', $template);
				}
			}
		}
	}

	public function replace_words(&$template){
        
        $patern    		= '/\$word([0-9]+)\$\!/';

		$blog_results	= common::get_stored_content_for_keyword_source($this->Keyword, 'GoogleBlogSearchParser');
		$text	= '';
		foreach($blog_results as $row){
			$text.= parent::clean_text($row['title'].' '.$row['description']);
		}
		$parts	= array();
		preg_match_all('/[a-zA-Z\s0-9\']+/', $text, $parts);
				
		$clean_text	= strtolower(implode(' ', $parts[0]));
		
		$words	= explode(' ', $clean_text);
		
		$stack	= array();
		$disconsider_keywords	= array('the','not','and','that','this','but','are','for','quot','has','have','com','with');
		
		foreach($words as $word){
			if(strlen(trim($word))>2 && !is_numeric($word) && !in_array(strtolower(trim($word)), $disconsider_keywords)){
				if(isset($stack[$word]))$stack[$word]++;
				else $stack[$word] = 1;
			}			
		}
		arsort($stack);
		//print_r($stack);die;

		$words_to_replace	= array();
		preg_match_all($patern, $template, $words_to_replace);
		//print_r($stack);die;
		
		if(isset($words_to_replace[0]) && count($words_to_replace[0])>0){
			
			foreach($words_to_replace[0] as $counter => $word_tpl){
				if(count($stack)>0){
					$word	= key($stack);
					array_shift($stack);
					$this->wordsArray[] = $word;
				}
				else{
					$word = '';
				}
				$template	= str_replace($word_tpl, $word, $template);
			}
		}
	}
	
	public function replace_blog_titles(&$template){
        $patern    					= '/\$blogsearch-title([0-9]+)\$\!/';
		$blog_results				= common::getContentForKeywordSource($this->Keyword, 'GoogleBlogSearchParser');
		$titles_to_replace	= array();
				
		$titles	= array();
		foreach($blog_results as $row){
			$titles[]=parent::clean_text($row['title']);
		}
		//echo '<pre> titles Result';
		//print_r($titles);
		preg_match_all($patern, $template, $titles_to_replace);
		if(isset($titles_to_replace[0]) && count($titles_to_replace[0])>0){		
			foreach($titles_to_replace[0] as $counter => $title_rep_str){
				if(isset($titles[$counter])){
					$template	= str_replace($title_rep_str, $titles[$counter], $template);
				}else{
					//replace with nothing
					$template	= str_replace($title_rep_str, '', $template);
				}
			}
		}
	}
	
	
	public function replace_sources_content(&$template){
        $patern    					= '/\$blogsearch-title([0-9]+)\$\!/';
		$blog_results				= common::getContentForKeywordSource($this->Keyword, 'GoogleBlogSearchParser');
		$titles_to_replace	= array();
				
		$titles	= array();
		foreach($blog_results as $row){
			$titles[]=parent::clean_text($row['title']);
		}
		//echo '<pre> titles Result';
		//print_r($titles);
		preg_match_all($patern, $template, $titles_to_replace);
		if(isset($titles_to_replace[0]) && count($titles_to_replace[0])>0){
		
			foreach($titles_to_replace[0] as $counter => $title_rep_str){
				if(isset($titles[$counter])){
					$template	= str_replace($title_rep_str, $titles[$counter], $template);
				}else{
					//replace with nothing
					$template	= str_replace($title_rep_str, '', $template);
				}
			}
		}
	}
	
	function replace_conditional_statements(&$template){
		/** for All Sources  **/
		//Parser
		
		$titles_to_replace = array();
		$sourcesArray = $this->all_sources;
		
		//echo "<br> ===== Source REsult ==== <br>";
		//print_r($this->all_sources);
		
			/** for Loop of Sources  */
		
		foreach($sourcesArray as $source_name=>$source){
			$rawData = array();	
			$completeContent = array();			
			//$tokens = explode('Parser',$source_class);
			//$source_name = strtolower($tokens[0]);
			$completeContent = $this->sources_array($source_name);
						
			/*if($source_name == 'ebay'){
				echo '<pre>';
				print_r($completeContent);
			}*/
			//foreach($completeContent as $content){
				
					foreach($completeContent[0] as $key=>$type){
						
					$titles_to_replace	= array();
					//$pattern = '/\{loop-([0-9-]+)-([0-9-]+):\$'.$source_name.'-'.$key.'([0-9]+)\*\|\|(.*?)endloop\}/si';
					
					
					// if nested array
					if(is_array($type)){						
						$nested_count = count($type);
						for($i=0;$i<$nested_count;$i++){
							foreach($type[$i] as $index_nested=>$t){
								$pattern = '/\{loop-([0-9-]+)-([0-9-]+):\$'.$source_name.'-([0-9]+)-'.$index_nested.'\$\!\*\|\?\?\|(.*?)endloop\}/si';
								preg_match_all($pattern, $template, $titles_to_replace);
								
								if(isset($titles_to_replace[0]) && count($titles_to_replace[0])>0){
	
									$intialText = $titles_to_replace[0];
									$startPoints = $titles_to_replace[1];
									$endPoints = $titles_to_replace[2];
									$replaceText = $titles_to_replace[3];
																		
									foreach($titles_to_replace[0] as $i => $titles){
										$subStr = '';
										$i = 0;							
										if(!empty($replaceText[$i])){
											for($start = $startPoints[$i]; $start<=$endPoints[$i] ; $start++ ){
												if(isset($completeContent[$start][$key]) && !empty($completeContent[$start][$key])){
													$subStr .= str_replace('|??|',$start,$replaceText[$i]);
												}
												else{
													break;
												}
											}
										}
										if(!empty($subStr)){
											$template = str_replace($titles,$subStr,$template);
										}else{
											$template = str_replace($titles,'',$template);
										}
									}
								}
								
							}
						}
					}
					// if Not nested array
					else{
						
						$pattern = '/\{loop-([0-9-]+)-([0-9-]+):\$'.$source_name.'-'.$key.'\$\!\*\|\?\?\|(.*?)endloop\}/si';
						preg_match_all($pattern, $template, $titles_to_replace);						
							
						if(isset($titles_to_replace[0]) && count($titles_to_replace[0])>0){

						$intialText = $titles_to_replace[0];
						$startPoints = $titles_to_replace[1];
						$endPoints = $titles_to_replace[2];
						$replaceText = $titles_to_replace[3];
						
						/*if($source_name == 'ebay'){
							echo '<br>intialText = ';
							print_r($intialText);
							
							echo '<br>startPoints = ';
							print_r($startPoints);
							
							echo '<br>endPoints = ';
							print_r($endPoints);
							
							echo '<br>replaceText = ';
							print_r($replaceText);
						}*/
						
						
						
					
							foreach($titles_to_replace[0] as $i => $titles){
							$subStr = '';
							$i = 0;							
							if(!empty($replaceText[$i])){
								for($start = $startPoints[$i]; $start<=$endPoints[$i] ; $start++ ){
									if(isset($completeContent[$start][$key]) && !empty($completeContent[$start][$key])){
										$subStr .= str_replace('|??|',$start,$replaceText[$i]);
									}
									else{
										break;
									}
								}
							}
							if(!empty($subStr)){
								$template = str_replace($titles,$subStr,$template);
							}else{
								$template = str_replace($titles,'',$template);
							}
						}
						}
					}					
					
					
					
				}
				
				
			// } // loop of complete content
		}
		
			
		
		foreach($sourcesArray as $source_name=>$source){
			
			$rawData = array();	
			$completeContent = array();
			
			//$tokens = explode('Parser',$source_class);
			//$source_name = strtolower($tokens[0]);

			$completeContent = $this->sources_array($source_name);
			
			//echo "<br> ===== Source $source_name ==== <br>";
			//print_r($completeContent);
			// Replace Fields with values 
			//$contentType = $completeContent[0];
			//$pattern = '/\{if:\$'.$source_name.'-'.$key.'([0-9]+)\*\|\|(.*?)\}/i';
			//foreach($completeContent as $content){
				
					if(count($completeContent[0])>0){
						foreach($completeContent[0] as $key=>$type){
							
							
							$titles_to_replace	= array();
							$raw_titles_to_replace = array();
							if(is_array($type)){
								$nested_count = count($type);
								for($i=0;$i<$nested_count;$i++){
									foreach($type[$i] as $index_nested=>$t){
										$titles_to_replace	= array();
										$raw_titles_to_replace = array();
										$pattern = '/\$'.$source_name.'-([0-9]+)-'.$index_nested.'([0-9]+)\$\!/si';
										preg_match_all($pattern, $template, $raw_titles_to_replace);
										if(isset($raw_titles_to_replace[0]) && count($raw_titles_to_replace[0])>0){
											foreach($raw_titles_to_replace[0] as $index=>$title_array){
												$temp_array = array($title_array=>$raw_titles_to_replace[1][$index].','.$raw_titles_to_replace[2][$index]);
												$titles_to_replace = array_merge($titles_to_replace, $temp_array);
											}						
											arsort($titles_to_replace);
											$fields = $titles_to_replace[0];
											$indexes = $titles_to_replace[1];
									
											foreach($titles_to_replace as $value=>$count){
												$count_tokens = explode(',',$count);
												$source_index = $count_tokens[0];
												$nest_index = $count_tokens[0];
												$replaceText = '';
												$searchText = $value;
												$replaceText = trim($completeContent[$source_index][$key][$nest_index][$index_nested]);
												if(!empty($replaceText)){
													$template = str_replace($searchText,$replaceText,$template);
													//$template = str_replace($searchText,$completeContent[$count][$key],$template);
												}else{
													$template = str_replace($searchText,'',$template);
												}
											}
										}
									}
								}
							}
							else{
								if($source_name == "feed" && strpos($key,"size") !== false){
									echo $pattern = '/\$'.$source_name.'-'.$key.'-([0-9]+)\$\!/si';
								}else{
									echo $pattern = '/\$'.$source_name.'-'.$key.'([0-9]+)\$\!/si';
								}
								echo "<br>";
								preg_match_all($pattern, $template, $raw_titles_to_replace);
								
								if(isset($raw_titles_to_replace[0]) && count($raw_titles_to_replace[0])>0){
									foreach($raw_titles_to_replace[0] as $index=>$title_array){
										$temp_array = array($title_array=>$raw_titles_to_replace[1][$index]);
										//print_r($temp_array);
										$titles_to_replace = array_merge($titles_to_replace, $temp_array);
									}	
									//print_r($titles_to_replace);
									arsort($titles_to_replace);
									//print_r($titles_to_replace);
									//$fields = $titles_to_replace[0];
									//$indexes = $titles_to_replace[1];
								
									foreach($titles_to_replace as $value=>$count){
										$replaceText = '';
										$searchText = $value;										
										$replaceText = trim($completeContent[$count][$key]);
										if(!empty($replaceText)){
											$template = str_replace($searchText,$replaceText,$template);
											//$template = str_replace($searchText,$completeContent[$count][$key],$template);
										}else{
											$template = str_replace($searchText,'',$template);
										}
									}														
								}
							}
							
							
						}
					}
			//} // loop of complete content
			
		}
			
		
		$this->remove_empty_nested_sources_words($template);
			
		$this->replace_all_empty_sources_words($template);
		//echo "<br><br>=================================================<br><br>";
		//echo $template;
		//echo "<br><br>=================================================<br><br>";
		
		
		$flag = true;
		$i = 0;
		
		
		$tries = 0;
		while(strpos($template, '{if:')!==FALSE && $tries<1000)
		{
			$titles_to_replace = array();
			//echo "<br> If = ";
			$if_condition = $this->findInner($template);
			//echo "<br>";
			if($if_condition){
				$offset = 0;
				$matchArray = array();
				//$if_start = strpos($if_condition,'{if:');
				//$if_end = strpos($if_condition,'endif}');
				
				if(strpos(strip_tags($if_condition),'{if:*|??|') !== false){
					$template = str_replace($if_condition,"",$template);
				}
				else{
					//$tokens = explode('||',$completeString);
					$titles_to_replace = array();
					$pattern = '/\{if:(.*?)\*\|\?\?\|(.*?)endif\}/si';
					
					preg_match_all($pattern, $if_condition, $titles_to_replace);
					//if(count($titles_to_replace[2])>0){
					//	print_r($titles_to_replace);
					//}
					if(isset($titles_to_replace[0]) && count($titles_to_replace[0])>0){
						foreach($titles_to_replace[0] as $key => $titles){
							$template = str_replace($titles,$titles_to_replace[2][$key],$template);
						}
					}
					
				}
			}
			$tries++;
		}
		unset($sourcesArray);
	}
	
	
	
	
	function sources_array($source_class){
		//$tokens = explode('Parser',$source_class);
		//$source_class = strtolower($source_class);
		//$source_name = strtolower($tokens[0]);		
		$rawData = array();
		$completeContent = array();
		$content = $this->all_sources[strtolower($source_class)];			
		foreach($content as $row){							
			foreach($row as $key=>$val){						
				if(isset($val) && $val!='<'){
					//if(is_array($val) && $source_class == 'amazondeepparser'){
					if(is_array($val)){
						$rawData[$key] = $val;
					}
					else{
						$rawData[$key] = $val;
						if(strtolower($key) == 'link'){
							/** for Domain **/ 
							preg_match('@^(?:http://)?([^/]+)@i',$row['link'], $matches);
							$rawData['domain'] = $matches[1];
						}
					}
				}
			}					
			array_push($completeContent,$rawData);
		}

			
		return $completeContent;
	}
	
	
	function replace_nested_if_sources(&$template){
		$titles_to_replace = array();
		$pattern = '/\{if:\$(.*?)-(.*?)\$\!\*\|\?\?\|(.*?)endif\}/si';
		//$pattern = '/\{loop-([0-9-]+)-([0-9-]+):\*\|\|(.*?)endloop\}/i';
		preg_match_all($pattern, $template, $titles_to_replace);
		if(isset($titles_to_replace[0]) && count($titles_to_replace[0])>0){
			foreach($titles_to_replace[0] as $titles){
				$template = str_replace($titles,'',$template);
			}
		}
	}
	
	function replace_junk_charcters(&$template){
		$titles_to_replace = array('*}','endif}');
		$template = str_replace($titles_to_replace,'',$template);
	}
	
	function replace_if_statements($titles_to_replace,&$template){
		if(isset($titles_to_replace[0]) && count($titles_to_replace[0])>0){
			$replaceText = $titles_to_replace[1];
			foreach($titles_to_replace[0] as $key=>$titles){
				if(!empty($replaceText[$key])){
					$template = str_replace($titles,$replaceText[$key],$template);
				}else{
					$template = str_replace($titles,'',$template);
				}
			}
		}
	}
	
	function replace_for_statements($titles_to_replace,&$template){
		
		if(isset($titles_to_replace[0]) && count($titles_to_replace[0])>0){
			$startPoints = $titles_to_replace[1];
			$endPoints = $titles_to_replace[2];
			$replaceText = $titles_to_replace[3];
			foreach($titles_to_replace[0] as $key => $titles){
				$subStr = '';
				/*echo '<br> key = '.$key; 
				echo '<br> Text = '.$titles;
				echo '<br> Start = '.$startPoints[$key];
				echo '<br> End = '.$endPoints[$key];
				echo '<br> Replace = '.$replaceText[$key];*/
				$i = 0;
				if(!empty($replaceText[$key])){
					for($i = $startPoints[$key]; $i <= $endPoints[$key]; $i++){
						$subStr .= $replaceText[$key].' ';
					}
				}
				//echo '<br>'. $i .'---'. $subStr;
				//echo '<br> Final String = '; echo $subStr.'<br>';
				if(!empty($subStr)){
					$template = str_replace($titles,$subStr,$template);
				}else{
					$template = str_replace($titles,'',$template);
				}
			}
		}
	}
	
	function remove_empty_words(&$template){
		$pattern = '/\{loop-([0-9-]+)-([0-9-]+):(.*?)\*\|\?\?\|(.*?)endloop\}/si';
		$titles_to_replace = array();
		preg_match_all($pattern, $template, $titles_to_replace);
		
		if(isset($titles_to_replace[0]) && count($titles_to_replace[0])>0){
			foreach($titles_to_replace[0] as $titles){
				$template = str_replace($titles,'',$template);
			}
		}
		
		$titles_to_replace = array();
		$pattern = '/\{if:\*\|\?\?\|(.*?)endif\}/si';
		//$pattern = '/\{loop-([0-9-]+)-([0-9-]+):\*\|\|(.*?)endloop\}/i';
		preg_match_all($pattern, $template, $titles_to_replace);
		//print_r($titles_to_replace);
		if(isset($titles_to_replace[0]) && count($titles_to_replace[0])>0){
			foreach($titles_to_replace[0] as $titles){
				$template = str_replace($titles,'',$template);
			}
		}
		
		
	}
	
	public function remove_empty_nested_sources_words(&$template){
		
		$sourcesArray = $this->all_sources;
		
		foreach($sourcesArray as $source_name=>$source){
			
			$rawData = array();	
			$completeContent = array();			
			//$tokens = explode('Parser',$source_class);
			$source_name = trim(strip_tags(strtolower($source_name)));
			
			$pattern = '/\$'.trim($source_name).'-([0-9]+)-(.*?)([0-9]+)\$\!/is';
			$titles_to_replace = array();
			preg_match_all($pattern, $template, $titles_to_replace);
				
					
			if(isset($titles_to_replace[0]) && count($titles_to_replace[0])>0){
				$intialText = $titles_to_replace[0];
				$startPoints = $titles_to_replace[1];
				$endPoints = $titles_to_replace[2];
				$replaceText = $titles_to_replace[4];
				
				foreach($titles_to_replace[0] as $i => $titles){					
					$template = str_replace($titles,'',$template);
				}
			}
			

			
			$pattern = '/\$'.trim($source_name).'-(.*?)([0-9]+)\$\!/is';
			$titles_to_replace = array();
			preg_match_all($pattern, $template, $titles_to_replace);
			if(isset($titles_to_replace[0]) && count($titles_to_replace[0])>0){
				$intialText = $titles_to_replace[0];
				$startPoints = $titles_to_replace[1];
				$endPoints = $titles_to_replace[2];
				$replaceText = $titles_to_replace[4];		
				foreach($titles_to_replace[0] as $i => $titles){					
					$template = str_replace($titles,'',$template);
				}
			}	
			//$pattern = '/\{loop-([0-9-]+)-([0-9-]+):\$'.$source_name.'-(.*?)([0-9]+)\*\|\|(.*?)endloop\}/si';
		}	
		
		unset($sourcesArray);	
	}
	
	public function replace_all_empty_sources_words(&$template){
		$titles_to_replace	= array();
		$pattern = '/\$(.*?)-(.*?)([0-9]+)\$\!/i';
		$titles_to_replace = array();
		preg_match_all($pattern, $template, $titles_to_replace);
		//print_r($titles_to_replace);
		if(isset($titles_to_replace[0]) && count($titles_to_replace[0])>0){
			$intialText = $titles_to_replace[0];
			$startPoints = $titles_to_replace[1];
			$endPoints = $titles_to_replace[2];
			//$replaceText = $titles_to_replace[4];			
			foreach($titles_to_replace[0] as $i => $titles){					
				if(strpos($titles,"*|??|") === false){
					$template = str_replace($titles,'',$template);
				}
			}
		}	
	}

	public function replace_subject_keyword(&$template,$keyword){
		$keyword	= str_replace('+', ' ', urldecode($keyword));
		$template	= str_replace('$keyword$!', $keyword, $template);	
	}
	
	public function replaceInnerWords(&$template){
		$tries = 0;
		while(strpos($template, '$word_count_') !== false  && $tries<1000)
		{
			$titles_to_replace = array();
			$if_condition = $this->findInnerWord($template);
			if($if_condition){
				$offset = 0;
				$matchArray = array();
				//$if_start = strpos($if_condition,'{if:');
				//$if_end = strpos($if_condition,'endif}');
				
			
					//$tokens = explode('||',$completeString);
					$titles_to_replace = array();
					$pattern = '/\$word_count_(.*?)\{(.*?)endword\}\$\!/si';
					preg_match_all($pattern, $if_condition, $titles_to_replace);
					if(isset($titles_to_replace[1][0]) && count($titles_to_replace[1][0])>0){
						foreach($titles_to_replace[0] as $key => $titles){
							$temp_title = parent::string_limit_words($titles_to_replace[2][$key],intval($titles_to_replace[1][$key]));
							$template = str_replace($titles,$temp_title,$template);
						}
					}
			}
			
			$tries++;
		}
	}
	
	public function findInnerWord($template){
		
		$forinnerChoose = false;
		$startPos = array();
		$endPost = array();
	
		$i = 0;
		$n = 0;
		while(strpos($template,'$word_count_',$n) !== false){
			$startPos[$i] = $n = strpos($template,'$word_count_',$n );
	    	$n++;
			$i++;
		}
		
		$i = 0;
		$n = 0;
		while(strpos($template,'endword}$!',$n) !== false){
			$endPost[$i] = $n = strpos($template,'endword}$!',$n );
		    $n++;
			$i++;
		}	
	
		$innerPostion = 0;	
		if(count($endPost) > 0){		
			for($c = count($endPost)-1; $c >= 0 ;$c--){
				if( $startPos[$c] < $endPost[0] ) {
					$innerPostion = $startPos[$c];
					break;
				}
			}
			$limit = ($endPost[0]) - $innerPostion;
			$forinnerChoose = substr($template,$innerPostion, $limit+10 );
		}
		return $forinnerChoose;	
	}
	
	function findInner($template){
		
		$forinnerChoose = false;
		$startPos = array();
		$endPost = array();
	
		$i = 0;
		$n = 0;
		while(strpos($template,'{if:',$n) !== false){
			$startPos[$i] = $n = strpos($template,'{if:',$n );
	    	$n++;
			$i++;
		}
		
		$i = 0;
		$n = 0;
		while(strpos($template,'endif}',$n) !== false){
			$endPost[$i] = $n = strpos($template,'endif}',$n );
		    $n++;
			$i++;
		}	
	
		$innerPostion = 0;	
		if(count($endPost) > 0){		
			for($c = count($endPost)-1; $c >= 0 ;$c--){
				if(isset($startPos[$c]) && isset($endPost[0])){
					if($startPos[$c] < $endPost[0] ) {
						$innerPostion = $startPos[$c];
						break;
					}
				}
			}
			$limit = ($endPost[0]) - $innerPostion;
			$forinnerChoose = substr($template,$innerPostion, $limit+6 );
		}
		return $forinnerChoose;	
	}

} 
?>
