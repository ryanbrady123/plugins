<?php

class Repin_Mass_Scheduler extends Common{

    private $id;
	private $status;
    private $tableName;


    function __construct() {
        $this->status = 0;
        $this->tableName = "repin_mass_scheduler";
    }
	
	public function getId(){
		return $this->id;
	}
	
	public function setId($val){
		$this->id = $val;
	} 

    public function getStatus() {
        return $this->status;
    }

    public function setStatus($status) {
        $this->status = $status;
    }
	

    public function getTableName() {
        return $this->tableName;
    }

    public function setTableName($tableName) {
        $this->tableName = $tableName;
    }

    public function getTableHeaders() {
        return $header = array('ID', ' Login', 'Password', 'Role Type');
    }
	public function getRecordsId($limit = "") {
       $sql = "SELECT id FROM ".$this->tableName." WHERE next_run < NOW() AND status = 0 ORDER BY next_run ASC ";
	   if($limit !=""){
	   		$sql .= " LIMIT ".$limit; 
	   }
       return $sql;
    }
	public function getRecordsById($ids) {
       $sql = "SELECT * FROM ".$this->tableName." WHERE id IN (".$ids.") ORDER BY next_run ASC ";
       return $sql;
    }
	public function getRecords($limit = "") {
       $sql = "SELECT * FROM ".$this->tableName." WHERE next_run < NOW() ORDER BY next_run ASC ";
	   if($limit !=""){
	   		$sql .= " LIMIT ".$limit; 
	   }
       return $sql;
    }
	
	  public function updateStatusByIds(){
		$sql = "UPDATE ".$this->tableName." SET status = " .$this->getStatus(). " WHERE  id IN(".$this->getId().")";
		return $sql;
	}
	
	public function create_table($thread_id){
		$sql = "";
		if(!empty($thread_id) && !is_null($thread_id)){
			$sql = str_replace("%thread_id%",$thread_id,TABLE_STRUCTURE_REPIN);
		}
		return $sql;
	}
	
	public function get_content($thread_id,$publish_date,$end_date){		
		$sql = "";
		if(!empty($thread_id) && !empty($publish_date)){
			$sql = "SELECT * FROM repin_thread_".$thread_id." WHERE publish_date < NOW() AND publish_date > DATE_SUB( NOW() , INTERVAL ".$end_date." MINUTE )";
		}
		return $sql;
	}
	
	public function delete_content($thread_id,$publish_date){		
		$sql = "";
		if(!empty($thread_id) && !empty($publish_date)){
			echo $sql = "DELETE FROM repin_thread_".$thread_id." WHERE publish_date < NOW()";
			echo '<br>';
		}
		return $sql;
	}
	
	
}

?>