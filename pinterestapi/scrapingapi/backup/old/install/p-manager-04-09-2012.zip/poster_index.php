<?php
	include_once('header.php');
	for($i=1;$i<=$poster_threads;$i++){
		$threadCount = shell_exec("/bin/ps aux | /bin/grep '".SITE_PATH."poster.php ".$i."' -c");
		echo "\n Thread = ".$threadCount ."\n";
		if($threadCount<=2){
			echo "/usr/bin/nohup  /usr/bin/php ".SITE_PATH."poster.php ".$i."& ";
			echo "\n\n";
			shell_exec("/usr/bin/nohup  /usr/bin/php ".SITE_PATH."poster.php ".$i."  > /dev/null & echo $!");
		}
	}
	$db->close();
	
	exit;





	// for simple poster
	include_once('header.php');
	$thread_count = shell_exec("/bin/ps aux | /bin/grep '".SITE_PATH."poster.php' -c");
	//$threadCount = shell_exec("/bin/ps aux | /bin/grep '".SITE_PATH."mass_schedular.php' -c");
	//echo "\n Thread = ".$threadCount ."\n";
	if($thread_count<=2){
		$available_thread = $poster_threads;
	}
	else{
		$available_thread = $poster_threads-($threadCount-1);
	}
	//echo "\navailableThread = ".$availableThread;
	//echo "\n";
	$limit = $available_thread*$poster_tasks_per_thread;
	$db->query("SELECT * FROM schedule_pins WHERE post_date <= NOW() AND status = 0 ORDER BY post_date ASC LIMIT ".$limit);
	$schedules = $db->fetch_all_assoc();
	$schedules_ids = array();
	if(count($schedules)>0){
		foreach($schedules as $sc){
			$schedules_ids[] = $sc['id'];
		}
		$all_ids = implode(",",$schedules_ids);
		$db->execute("UPDATE schedule_pins SET status = ".time()." WHERE id IN(".$all_ids.")");
		//echo "\n schedules count = ".count($schedules);
		//echo "\n";
		$current_thread_count = ceil(count($schedules)/$availableThread);
		//echo "\n";
		$thread_chunks = array_chunk($schedules_ids,$current_thread_count);
		foreach($thread_chunks as $chunks){
			$threads = implode(",",$chunks);
			echo "/usr/bin/nohup  /usr/bin/php ".SITE_PATH."poster.php ".$threads."& ";
			echo "\n\n";
			shell_exec("/usr/bin/nohup  /usr/bin/php ".SITE_PATH."poster.php ".$threads."  > /dev/null & echo $!");
			//$threadCount = shell_exec("/bin/ps aux | /bin/grep '".SITE_PATH."mass_schedular_db.php' -c");
		}
	}
$db->close();