<?php

include_once('header.php');

$allFollowersArray = array();
$allFollowingsArray = array();


unset($argv[0]);// to remove the first index which will be path of cron
$implodeStr = $argv[1];

if(isset($_GET['user'])){
	$implodeStr = $_GET['user'];
}

$objAccounts->setUsername($implodeStr);
$db->query($objAccounts->getAccountDetails());

$accounts = $db->fetch_all_assoc();


$previousUser = '';
$currentUser = '';
$loggedScreenName = '';
$result = '';
$userId = 0;

$current_auth_token = '';

$followLogText = '';

$current_error_code = '';


foreach ($accounts as $acc){
	$start_time = microtime(true);//(round($usec, 2) + (float)$sec)
		
	$file = SITE_PATH.'confirmemaillog/';
	$error = '';
	$debug_text = '';
	
	//if($acc['created'] == 200 && (($acc['login_active'] >= 150 && $acc['login_active'] <= (150+$max_failure))  || ($acc['update_email'] >= 150 && $acc['update_email'] <= (150+$max_failure))  ) && time() > $acc['last_run']){
		
		
		
		
		if($acc['login_active'] >= 150 && $acc['login_active'] <= (150+$max_failure)){
			echo 150+$max_failure;
			$post_where['to_email']['value'] = $acc['email'];
			$post_where['to_email']['operator'] = 'exact';	 
			
			$post_where['from_domain']['value'] = 'postmaster.twitter.com' ;
			$post_where['from_domain']['operator'] = 'like' ;
			 
			$post_where['subject']['value'] = 'Confirm your Twitter account, '.$acc['username'].'!' ;
			$post_where['subject']['operator'] = 'like' ;
			$apiresult = $objEmailAPI->confirmEmail($post_where,$confirm_email_api_url,$confirm_email_api_username,$confirm_email_api_password);
			$loggedScreenName = '';
						
			$cookie_name = strtolower($acc['username']);			
			$objBasicFunction->setProxy($acc['proxy']);
			$objBasicFunction->setMaxFailure($max_failure);
			$objAccounts->setUsername($acc['username']);
				
			$twitterLoginResult = $objTwitter->getLoginPage($acc['proxy'],$cookie_name);
			if(empty($twitterLoginResult)){
				$sql = '';
				$objBasicFunction->updateLoginStatus($acc['username'],$acc['login_active'],PROXY_ERROR);
				$current_error_code = PROXY_ERROR;
				$error = $acc['username']." | Confirm Email | Confirm Email Failed | Error Code =  ".$current_error_code."\n";
				$objCommon->saveLog($file,$acc['username'],$error);
				continue;
			}
			
			echo $loggedScreenName = $objBasicFunction->authenticate($acc['username'],$acc['password'],$twitterLoginResult,$cookie_name);
			if (empty($loggedScreenName)) {
				$objBasicFunction->updateLoginStatus($acc['username'],$acc['login_active'],LOGIN_FAILED_ERROR);
			}
			
			if(!empty($loggedScreenName)){			
				$suspended = 0;
				$objAccounts->setUsername($acc['username']);
				$accounts_details = $objTwitter->getAccountDetail($acc['username']);				
				$current_auth_token = $accounts_details['postAuthenticityToken'];
				$objTwitter->setGolbalAuthToken($current_auth_token);
				$suspended = $objBasicFunction->is_suspended($accounts_details,$acc['username']);
					
				if($suspended){
					$current_error_code = PROXY_ERROR;
					$error = $acc['username']." | Confirm Email | Confirm Email Failed | Error Code =  -1 (Suspended)\n";
					$objCommon->saveLog($file,$acc['username'],$error);	
					continue;
				}	
			}
			
			
			if(!empty($apiresult[0]['html_content'])){
				$apiresult[0]['html_content'];
				foreach($apiresult as $api){
					$html = $api['html_content'];
					//http://twitter.com/account/confirm_email/Moldoverwater/F5C47-5BE2A-130434?utm_campaign=twitter20080313004044&utm_medium=email&utm_source=validate_email
					$pattern = '/\<a href="http:\/\/twitter.com\/account\/confirm_email\/(.*?)"\>/si';
					preg_match_all($pattern,$html,$match);
					$redirect_after_login = '';
					if(isset($match[1][0]) && !empty($match[1][0])){
						//$url = 'http://twitter.com/account/confirm_email/'.$match[1][0];
						$redirect_after_login = trim($match[1][0]);
							
						if(!empty($loggedScreenName)){									
								$confirmResult = $objTwitter->confirmEmail($redirect_after_login,$acc['proxy'],$cookie_name);
								echo '<textarea cols="100" rows="50" id="active">'.$confirmResult.'</textarea>';
								$pattern = 'Your account has been confirmed. Thanks!';
								$pos = strpos(strtolower($confirmResult),strtolower($pattern));
							
								//if($pos !== false){
									$objAccounts->setUsername($acc['username']);
									$db->execute($objAccounts->updateLoginActive(0));
									$current_error_code = '0 (Confirmed)';
								//}
							}
							else{
								$objAccounts->setUsername($acc['username']);
								$objAccounts->setLastRun(time()+($confirm_email_time*60));// addding minutes for confirm email address to work
								$db->execute($objAccounts->updateLastRun());
							}
					}
					else{
						$objAccounts->setUsername($acc['username']);
						$objAccounts->setLastRun(time()+($confirm_email_time*60));// addding minutes for confirm email address to work
						$db->execute($objAccounts->updateLastRun());
					}
				}
			}
			else{
				if(!empty($loggedScreenName)){					
					$resendconfirmResult = $objTwitter->resendConfirmEmail($current_auth_token,$acc['username']);
					if($resendconfirmResult->messageForFlash != 'A confirmation email has been sent to you.'){
						echo "\n Resend email failed. \n";
						/*$objAccounts->setUsername($acc['username']);
						$objAccounts->setLastRun(time()+($confirm_email_time*60));// addding minutes for confirm email address to work
						$db->execute($objAccounts->updateLastRun());*/
						
					}
					else{
						echo "\n\n ".$resendconfirmResult->messageForFlash;
					}
					$objAccounts->setUsername($acc['username']);
					$objAccounts->setLastRun(time()+($confirm_email_time*60));// addding minutes for confirm email address to work
					$db->execute($objAccounts->updateLastRun());
				}
			}
			
		}
		if($acc['update_email'] >= 150 && $acc['update_email'] <= (150+$max_failure)){
			
			$post_where['to_email']['value'] = $acc['email'] ;
			$post_where['to_email']['operator'] = 'exact' ;			 
			
			$post_where['from_domain']['value'] = 'postmaster.twitter.com' ;
			$post_where['from_domain']['operator'] = 'like' ;
			 
			$post_where['subject']['value'] = 'Confirm your Twitter contact email, '.$acc['username'] ;
			$post_where['subject']['operator'] = 'like' ;
				
			$apiresult = $objEmailAPI->confirmEmail($post_where,$confirm_email_api_url,$confirm_email_api_username,$confirm_email_api_password);
			if(!empty($apiresult[0]['html_content'])){
				foreach($apiresult as $api){
						$html = $api['html_content'];
						$pattern = '/\<a href="http:\/\/twitter.com\/account\/confirm_email\/(.*?)"\>/si';
						preg_match_all($pattern,$html,$match);
						if(isset($match[1][0]) && !empty($match[1][0])){
							//$url = 'http://twitter.com/account/confirm_email/'.$match[1][0];							
							$twitterLoginResult = $objTwitter->confirmEmail($match[1][0],$acc['proxy'],strtolower($acc['username']));
							if(!empty($loggedScreenName)){
								// Change login_active
								$pattern = 'Your new contact email <strong>('.$acc['email'].')</strong> has been confirmed.';
								$pos = strpos($twitterLoginResult,$pattern);
								
								if($pos !== false){
									$objAccounts->setUsername($acc['username']);
									$db->execute($objAccounts->updateUpdateEmail(200));
									$current_error_code = 200;
								}
							}			
						}
					}
			}
			else{			
				if(!empty($loggedScreenName)){					
					$confirmResult = $objTwitter->resendConfirmEmail($current_auth_token,$acc['username']);
					if($confirmResult->messageForFlash != 'A confirmation email has been sent to you.'){
						echo "\n Resend email failed. \n";
						$objAccounts->setUsername($acc['username']);
						$objAccounts->setLastRun(time()+($confirm_email_time*60));// addding minutes for confirm email address to work
						$db->execute($objAccounts->updateLastRun());
					}else{
						echo "\n\n ".$resendconfirmResult->messageForFlash;
					}
				}
			}
			
		}
		$error = $acc['username']." | Confirm Email | Error Code =  ".$current_error_code."\n";
	//}
	$objCommon->saveLog($file,$acc['username'],$error);
	$debug_text = "\n ------- Confirm Email Finished ------- \n Total Time = ".((float)(microtime(true) - $start_time));
	$objCommon->saveDebugContent($acc['username'],$debug_text);
}

$currentProcess = SITE_PATH."confirm_accounts.php ".$implodeStr;

include_once('footer.php');


